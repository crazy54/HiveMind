# Resource Tracking and Cleanup System

## Overview

HiveMind now includes a comprehensive resource tracking and cleanup system that enables safe teardown of deployments and prevents orphaned AWS resources.

## Key Features

### 1. Resource Tracking
Every AWS resource created during deployment is tracked with:
- **Resource Type**: vpc, ec2_instance, rds_instance, security_group, subnet, etc.
- **Resource ID**: AWS resource identifier (e.g., vpc-12345, i-abcdef)
- **ARN**: Full Amazon Resource Name
- **Dependencies**: List of resources this depends on
- **Teardown Order**: Priority for deletion (higher = delete first)
- **Cost Tracking**: Monthly cost estimate
- **AWS Tags**: Standard tags for identification and cost tracking
- **Timestamps**: Creation and deletion times

### 2. AWS Tagging Scheme

All resources are tagged with:
- `HM-DeploymentId`: Unique deployment UUID
- `HM-AppIdentifier`: Unique app key (format: `repo-name-deployment-id-short`)
- `HM-ManagedBy`: "HiveMind"
- `HM-Repository`: Full repository URL
- `HM-Application`: Repository name
- `HM-CreatedAt`: ISO timestamp
- `HM-Status`: Current deployment status

These tags enable:
- Resource discovery (find all resources for a deployment)
- Cost tracking (filter AWS Cost Explorer by deployment)
- Cleanup (identify orphaned resources)
- Isolation (prevent conflicts between deployments)

### 3. Teardown Order

Resources are deleted in dependency order to prevent errors:

| Resource Type | Teardown Order | Notes |
|--------------|----------------|-------|
| EC2 Instances | 100 | Delete first |
| RDS Instances | 95 | Delete databases |
| Security Groups | 80 | Delete after instances |
| Route Tables | 70 | Delete after instances |
| Subnets | 60 | Delete after security groups |
| Internet Gateways | 50 | Delete after subnets |
| VPC | 10 | Delete last |

Higher numbers are deleted first to respect dependencies.

### 4. Deployment Index

A lightweight index (`deployments/_index.json`) provides fast lookups without loading full state files:

```json
{
  "deployments": {
    "abc-123": {
      "deployment_id": "abc-123",
      "repo_url": "https://github.com/user/app",
      "repo_name": "app",
      "app_identifier": "app-abc12345",
      "status": "completed",
      "resource_count": 7,
      "total_cost": 45.23,
      "started_at": "2025-01-12T10:00:00",
      "completed_at": "2025-01-12T10:15:00"
    }
  }
}
```

## Usage

### Deploy with Resource Tracking

Resources are automatically tracked during deployment:

```bash
# Deploy application
python3 src/cli.py deploy https://github.com/user/app "Deploy app"

# Resources are tracked in deployments/<deployment-id>.json
```

### List Deployments

```bash
# List all deployments
python3 src/cli.py list

# Filter by status
python3 src/cli.py list --status completed

# Show statistics
python3 src/cli.py list --verbose
```

### Destroy Deployment

```bash
# Destroy with confirmation
python3 src/cli.py destroy <deployment-id>

# Force destroy (skip confirmation)
python3 src/cli.py destroy <deployment-id> --force

# Skip RDS final snapshot (faster)
python3 src/cli.py destroy <deployment-id> --skip-snapshot

# Verbose output
python3 src/cli.py destroy <deployment-id> --verbose
```

### Check Status

```bash
# View deployment status
python3 src/cli.py status <deployment-id>

# View deployment plan
python3 src/cli.py plan <deployment-id>
```

## Architecture

### State Management

```
deployments/
├── _index.json                    # Fast lookup index
├── abc-123.json                   # Full deployment state
└── def-456.json                   # Another deployment
```

Each deployment state file contains:
- Deployment metadata
- Technology stack information
- Infrastructure details
- **Resource tracking** (NEW)
- Deployment configuration
- Security configuration
- Logs and timestamps

### Resource Lifecycle

1. **Creation**: Resources created by provisioner agents
2. **Tracking**: Resource info added to deployment state
3. **Tagging**: AWS tags applied for identification
4. **Monitoring**: Resources tracked throughout lifecycle
5. **Deletion**: Resources deleted in correct order
6. **Verification**: Deletion verified via AWS API

### Cleanup Process

```python
# 1. Load deployment state
state = conductor.get_status(deployment_id)

# 2. Get resources in teardown order
resources = state.get_resources_by_teardown_order()

# 3. Delete each resource
for resource in resources:
    delete_resource(resource, state)
    state.mark_resource_deleted(resource.resource_id)

# 4. Verify all deleted
if state.all_resources_deleted():
    state.status = "destroyed"
```

## API Reference

### DeploymentState Methods

```python
# Get standard AWS tags
tags = state.get_resource_tags()

# Get resources in teardown order
resources = state.get_resources_by_teardown_order()

# Mark resource as deleted
state.mark_resource_deleted(resource_id)

# Get active resources
active = state.get_active_resources()

# Check if all deleted
all_deleted = state.all_resources_deleted()

# Calculate total cost
cost = state.get_total_cost()
```

### Deployment Index Functions

```python
from src.tools.deployment_index import (
    update_index,
    list_deployments,
    find_by_repo,
    find_by_status,
    get_deployment_summary,
    get_deployment_stats
)

# Update index
update_index(state)

# List deployments
deployments = list_deployments(status="completed", limit=10)

# Find by repository
deployments = find_by_repo("https://github.com/user/app")

# Get quick summary
summary = get_deployment_summary(deployment_id)

# Get statistics
stats = get_deployment_stats()
```

### Cleanup Functions

```python
from src.tools.cleanup_tools import (
    destroy_deployment,
    delete_resource,
    verify_resource_deleted,
    get_teardown_order
)

# Destroy entire deployment
results = destroy_deployment(state, skip_final_snapshot=False)

# Delete single resource
success, message = delete_resource(resource, state)

# Verify deletion
deleted = verify_resource_deleted(resource)

# Get teardown order
order = get_teardown_order("ec2_instance")  # Returns 100
```

## Error Handling

### Partial Deletion Failures

If some resources fail to delete:

```bash
❌ Destruction failed!
Deleted: 5 resources
Failed: 2 resources

❌ Errors:
  - Failed to delete security group sg-12345: DependencyViolation
  - Failed to delete subnet subnet-67890: DependencyViolation
```

The deployment state is updated with:
- Which resources were successfully deleted
- Which resources failed and why
- Status set to "failed"
- Error messages logged

### Manual Cleanup

If automatic cleanup fails, you can:

1. Check the deployment state for resource IDs
2. Use AWS Console to manually delete resources
3. Follow the teardown order (instances → databases → networking → VPC)
4. Use AWS tags to find all resources: `HM-DeploymentId=abc-123`

## Cost Tracking

### Per-Deployment Costs

```python
# Get total monthly cost
cost = state.get_total_cost()

# Get cost breakdown
for resource in state.resources:
    print(f"{resource.resource_type}: ${resource.cost_per_month}/month")
```

### AWS Cost Explorer

Use AWS tags to filter costs:
- Filter by `HM-DeploymentId` for specific deployment
- Filter by `HM-Application` for all deployments of an app
- Filter by `HM-ManagedBy=HiveMind` for all HiveMind resources

## Best Practices

### 1. Always Use Destroy Command

Don't manually delete resources - use the destroy command to ensure proper cleanup:

```bash
python3 src/cli.py destroy <deployment-id>
```

### 2. Monitor Resource Costs

Regularly check deployment costs:

```bash
python3 src/cli.py list --verbose
```

### 3. Clean Up Failed Deployments

Failed deployments may have partial resources:

```bash
# Check status
python3 src/cli.py status <deployment-id>

# Destroy if needed
python3 src/cli.py destroy <deployment-id>
```

### 4. Use What-If Mode

Test deployments before creating resources:

```bash
python3 src/cli.py deploy <repo-url> "Test" --what-if
```

### 5. Tag Resources Consistently

All resources should have HiveMind tags. If you manually create resources, add:
- `HM-ManagedBy=HiveMind`
- `HM-DeploymentId=<deployment-id>`

## Troubleshooting

### Resources Not Deleting

**Problem**: Security group won't delete due to dependencies

**Solution**: 
1. Check what's using the security group
2. Delete dependent resources first
3. Retry deletion

### Orphaned Resources

**Problem**: Resources exist but not in deployment state

**Solution**:
1. Find resources by AWS tags: `HM-DeploymentId=abc-123`
2. Manually delete in correct order
3. Update deployment state if needed

### Index Out of Sync

**Problem**: Index doesn't match actual deployments

**Solution**:
```python
from src.tools.deployment_index import DeploymentIndex

index = DeploymentIndex()
count = index.rebuild_index()
print(f"Indexed {count} deployments")
```

## Future Enhancements

Potential improvements:
- Automatic orphan resource detection
- Cost alerts when threshold exceeded
- Scheduled cleanup of old deployments
- Resource usage analytics
- Multi-region support
- Backup/restore functionality
- Resource change tracking (drift detection)

## Related Documentation

- [QUICK_START.md](QUICK_START.md) - Getting started guide
- [WHAT_IF_MODE.md](WHAT_IF_MODE.md) - What-if mode documentation
- [TESTING_GUIDE.md](TESTING_GUIDE.md) - Testing guide
- [CLI_COLOR_SCHEME.md](CLI_COLOR_SCHEME.md) - CLI color scheme
