#!/usr/bin/env python3
"""Quick validation script for HiveMind system."""
import sys

def validate_imports():
    """Validate all agent imports work."""
    print("🔍 Validating imports...")
    
    try:
        from src.agents.strands_conductor import StrandsConductorAgent
        print("  ✅ HiveMind Control Plane")
    except Exception as e:
        print(f"  ❌ HiveMind Control Plane: {e}")
        return False
    
    try:
        from src.agents.strands_compiler import run_compiler_agent
        print("  ✅ HiveMind DevOps")
    except Exception as e:
        print(f"  ❌ HiveMind DevOps: {e}")
        return False
    
    try:
        from src.agents.strands_server_monkey import run_provisioner_agent
        print("  ✅ HiveMind SysEng")
    except Exception as e:
        print(f"  ❌ HiveMind SysEng: {e}")
        return False
    
    try:
        from src.agents.strands_deployer import run_deployer_agent
        print("  ✅ HiveMind Release-Engineer")
    except Exception as e:
        print(f"  ❌ HiveMind Release-Engineer: {e}")
        return False
    
    try:
        from src.agents.strands_sheriff import run_sheriff_agent
        print("  ✅ HiveMind SecOps")
    except Exception as e:
        print(f"  ❌ HiveMind SecOps: {e}")
        return False
    
    return True


def validate_agent_creation():
    """Validate agents can be instantiated."""
    print("\n🔧 Validating agent creation...")
    
    try:
        from src.agents.strands_conductor import StrandsConductorAgent
        conductor = StrandsConductorAgent()
        print("  ✅ Conductor instantiated")
    except Exception as e:
        print(f"  ❌ Conductor: {e}")
        return False
    
    return True


def validate_system_prompts():
    """Validate system prompts exist."""
    print("\n📝 Validating system prompts...")
    
    try:
        from src.agents.strands_conductor import CONDUCTOR_SYSTEM_PROMPT
        assert "HiveMind Control Plane" in CONDUCTOR_SYSTEM_PROMPT
        print("  ✅ Conductor prompt")
    except Exception as e:
        print(f"  ❌ Conductor prompt: {e}")
        return False
    
    try:
        from src.agents.strands_compiler import COMPILER_SYSTEM_PROMPT
        assert "HiveMind DevOps" in COMPILER_SYSTEM_PROMPT
        print("  ✅ Compiler prompt")
    except Exception as e:
        print(f"  ❌ Compiler prompt: {e}")
        return False
    
    try:
        from src.agents.strands_server_monkey import PROVISIONER_SYSTEM_PROMPT
        assert "HiveMind SysEng" in PROVISIONER_SYSTEM_PROMPT
        print("  ✅ Provisioner prompt")
    except Exception as e:
        print(f"  ❌ Provisioner prompt: {e}")
        return False
    
    try:
        from src.agents.strands_deployer import DEPLOYER_SYSTEM_PROMPT
        assert "HiveMind Release-Engineer" in DEPLOYER_SYSTEM_PROMPT
        print("  ✅ Deployer prompt")
    except Exception as e:
        print(f"  ❌ Deployer prompt: {e}")
        return False
    
    try:
        from src.agents.strands_sheriff import SHERIFF_SYSTEM_PROMPT
        assert "HiveMind SecOps" in SHERIFF_SYSTEM_PROMPT
        print("  ✅ Sheriff prompt")
    except Exception as e:
        print(f"  ❌ Sheriff prompt: {e}")
        return False
    
    return True


def main():
    """Run all validations."""
    print("="*60)
    print("HiveMind System Validation")
    print("="*60)
    
    all_passed = True
    
    if not validate_imports():
        all_passed = False
    
    if not validate_agent_creation():
        all_passed = False
    
    if not validate_system_prompts():
        all_passed = False
    
    print("\n" + "="*60)
    if all_passed:
        print("✅ ALL VALIDATIONS PASSED!")
        print("="*60)
        print("\nThe HiveMind system is ready to use.")
        print("\nNext steps:")
        print("  1. Run tests: pytest -v")
        print("  2. Test manually: python test_agents_manual.py")
        print("  3. Deploy an app: Use the CLI or Conductor directly")
        return 0
    else:
        print("❌ SOME VALIDATIONS FAILED")
        print("="*60)
        print("\nPlease fix the errors above before proceeding.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
