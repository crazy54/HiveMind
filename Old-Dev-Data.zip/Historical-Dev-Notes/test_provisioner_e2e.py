#!/usr/bin/env python3
"""
End-to-End Test for Provisioner Agent (What-If Mode)
Tests infrastructure planning without creating actual AWS resources
"""
import time
import json
from datetime import datetime
from src.agents.strands_conductor import StrandsConductorAgent


def test_provisioner_whatif():
    """Run Provisioner E2E test in What-If mode"""
    print("=" * 80)
    print("☁️  PROVISIONER (WHAT-IF MODE) - END-TO-END TEST")
    print("=" * 80)
    print()
    
    # Test configuration
    repo_path = "./hello-world-repo"
    description = "Simple Python Hello World application for testing"
    deployment_id = "test-provisioner-e2e"
    
    print(f"📋 Test Configuration:")
    print(f"   Repository: {repo_path}")
    print(f"   Description: {description}")
    print(f"   Mode: WHAT-IF (dry_run=True)")
    print(f"   Deployment ID: {deployment_id}")
    print()
    
    # Start timing
    start_time = time.time()
    print(f"⏱️  Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Run Conductor in What-If mode (includes Provisioner)
    print("🚀 Running Conductor with Provisioner (What-If Mode)...")
    print("-" * 80)
    
    try:
        conductor = StrandsConductorAgent()
        
        result = conductor.deploy(
            repo_url=repo_path,
            description=description,
            dry_run=True  # What-If mode!
        )
        
        # End timing
        end_time = time.time()
        duration = end_time - start_time
        
        print()
        print("-" * 80)
        print(f"⏱️  End Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"⏱️  Duration: {duration:.2f} seconds")
        print()
        
        # Display results
        print("=" * 80)
        print("📊 TEST RESULTS")
        print("=" * 80)
        print()
        
        print(f"✅ Success: {result.success}")
        print(f"🔮 What-If Mode: {result.state.dry_run if (hasattr(result, 'state') and result.state) else 'Unknown'}")
        print()
        
        if result.success and hasattr(result, 'state') and result.state:
            state = result.state
            
            print("💰 Predicted Costs:")
            if state.predicted_costs:
                costs = state.predicted_costs
                print(f"   Total Monthly: ${costs.get('total_monthly', 0):.2f}")
                if 'ec2' in costs:
                    print(f"   EC2: ${costs['ec2'].get('monthly', 0):.2f}/month")
                if 'rds' in costs:
                    print(f"   RDS: ${costs['rds'].get('monthly', 0):.2f}/month")
                if 'data_transfer' in costs:
                    print(f"   Data Transfer: ${costs['data_transfer'].get('monthly', 0):.2f}/month")
            else:
                print("   - No cost predictions generated")
            print()
            
            print("🏗️  Predicted Resources:")
            if state.predicted_resources:
                resources = state.predicted_resources
                print(f"   VPCs: {resources.get('vpcs', 0)}")
                print(f"   EC2 Instances: {resources.get('ec2_instances', 0)}")
                print(f"   Security Groups: {resources.get('security_groups', 0)}")
                if resources.get('rds_instances', 0) > 0:
                    print(f"   RDS Instances: {resources.get('rds_instances', 0)}")
                if resources.get('load_balancers', 0) > 0:
                    print(f"   Load Balancers: {resources.get('load_balancers', 0)}")
            else:
                print("   - No resource predictions generated")
            print()
            
            print("⏱️  Predicted Timeline:")
            if state.predicted_timeline:
                timeline = state.predicted_timeline
                print(f"   Total: {timeline.get('total_minutes', 0)} minutes")
            else:
                print("   - No timeline predictions generated")
            print()
            
            print("📋 Deployment State:")
            print(f"   Status: {state.status}")
            print(f"   Deployment ID: {state.deployment_id}")
            print(f"   Region: {state.region}")
            print()
            
            print("📝 Logs (last 10):")
            if state.logs:
                for log in state.logs[-10:]:
                    print(f"   {log}")
            else:
                print("   - No logs available")
            print()
            
        else:
            print(f"❌ Error: {result.error if hasattr(result, 'error') else 'Unknown error'}")
            print(f"❌ State: {result.state if hasattr(result, 'state') else 'No state'}")
            print()
            if hasattr(result, 'state') and result.state and result.state.logs:
                print("📝 Logs:")
                for log in result.state.logs:
                    print(f"   {log}")
            print()
        
        # Performance metrics
        print("=" * 80)
        print("📈 PERFORMANCE METRICS")
        print("=" * 80)
        print(f"Duration: {duration:.2f} seconds")
        print(f"Expected: < 180 seconds (3 minutes)")
        print(f"Status: {'✅ PASS' if duration < 180 else '❌ FAIL'}")
        print()
        
        # Success criteria check
        print("=" * 80)
        print("✅ SUCCESS CRITERIA")
        print("=" * 80)
        
        has_state = hasattr(result, 'state')
        has_predictions = has_state and (
            result.state.predicted_costs or 
            result.state.predicted_resources or 
            result.state.predicted_timeline
        )
        no_real_resources = has_state and result.state.dry_run
        
        criteria = {
            "Workflow completed successfully": result.success,
            "No crashes or errors": result.success,
            "Completed within 3 minutes": duration < 180,
            "Infrastructure plan generated": has_predictions,
            "Cost estimates provided": has_state and result.state.predicted_costs is not None,
            "No actual AWS resources created": no_real_resources,
            "What-If mode operated correctly": no_real_resources,
        }
        
        all_passed = all(criteria.values())
        
        for criterion, passed in criteria.items():
            status = "✅ PASS" if passed else "❌ FAIL"
            print(f"{status} - {criterion}")
        
        print()
        print("=" * 80)
        print(f"OVERALL: {'✅ TEST PASSED' if all_passed else '❌ TEST FAILED'}")
        print("=" * 80)
        print()
        
        # Save detailed results
        results_file = "test_results_provisioner.json"
        with open(results_file, 'w') as f:
            json.dump({
                "test": "Provisioner (What-If Mode) E2E",
                "timestamp": datetime.now().isoformat(),
                "duration_seconds": duration,
                "success": result.success,
                "criteria_passed": all_passed,
                "what_if_mode": no_real_resources,
                "predictions_generated": has_predictions,
                "result": {
                    "success": result.success,
                    "deployment_id": result.deployment_id if hasattr(result, 'deployment_id') else None,
                    "state": {
                        "status": result.state.status if has_state else None,
                        "dry_run": result.state.dry_run if has_state else None,
                        "predicted_costs": result.state.predicted_costs if has_state else None,
                        "predicted_resources": result.state.predicted_resources if has_state else None,
                        "predicted_timeline": result.state.predicted_timeline if has_state else None,
                    } if has_state else None
                }
            }, f, indent=2)
        
        print(f"📝 Detailed results saved to: {results_file}")
        print()
        
        return all_passed
        
    except Exception as e:
        end_time = time.time()
        duration = end_time - start_time
        
        print()
        print("=" * 80)
        print("❌ TEST FAILED WITH EXCEPTION")
        print("=" * 80)
        print(f"Error: {str(e)}")
        print(f"Duration: {duration:.2f} seconds")
        print()
        
        import traceback
        print("Traceback:")
        print("-" * 80)
        traceback.print_exc()
        print("-" * 80)
        print()
        
        return False


if __name__ == "__main__":
    success = test_provisioner_whatif()
    exit(0 if success else 1)
