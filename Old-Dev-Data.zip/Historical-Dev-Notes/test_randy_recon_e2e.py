#!/usr/bin/env python3
"""
End-to-End Test for Randy Recon Agent
Tests repository analysis against hello-world-repo
"""
import time
import json
from datetime import datetime
from src.agents.strands_recon import run_recon_agent


def test_randy_recon():
    """Run Randy Recon E2E test"""
    print("=" * 80)
    print("🔍 RANDY RECON - END-TO-END TEST")
    print("=" * 80)
    print()
    
    # Test configuration
    repo_path = "./hello-world-repo"  # Local test repository
    description = "Simple Python Hello World application for testing"
    
    print(f"📋 Test Configuration:")
    print(f"   Repository: {repo_path}")
    print(f"   Description: {description}")
    print()
    
    # Start timing
    start_time = time.time()
    print(f"⏱️  Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Run Randy Recon
    print("🚀 Running Randy Recon...")
    print("-" * 80)
    
    try:
        result = run_recon_agent(
            repo_url=repo_path,
            description=description,
            timeout=120  # 2 minute timeout for test
        )
        
        # End timing
        end_time = time.time()
        duration = end_time - start_time
        
        print()
        print("-" * 80)
        print(f"⏱️  End Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"⏱️  Duration: {duration:.2f} seconds")
        print()
        
        # Display results
        print("=" * 80)
        print("📊 TEST RESULTS")
        print("=" * 80)
        print()
        
        print(f"✅ Success: {result.get('success', False)}")
        print()
        
        if result.get('success'):
            print("📄 Documentation Found:")
            for doc in result.get('documentation_found', []):
                print(f"   - {doc}")
            print()
            
            print("🔧 Required Services:")
            services = result.get('required_services', [])
            if services:
                for service in services:
                    print(f"   - {service}")
            else:
                print("   - None detected")
            print()
            
            print("🌍 Environment Variables:")
            env_vars = result.get('environment_variables', {})
            if env_vars:
                for key, value in env_vars.items():
                    print(f"   - {key}: {value}")
            else:
                print("   - None detected")
            print()
            
            print("🚪 Ports:")
            ports = result.get('ports', [])
            if ports:
                for port in ports:
                    print(f"   - {port}")
            else:
                print("   - None detected")
            print()
            
            print("💡 Recommendations:")
            recommendations = result.get('recommendations', [])
            if recommendations:
                for rec in recommendations:
                    print(f"   - {rec}")
            else:
                print("   - None provided")
            print()
            
            print("🤖 Agent Output:")
            print("-" * 80)
            print(result.get('agent_output', 'No output'))
            print("-" * 80)
            print()
            
        else:
            print(f"❌ Error: {result.get('error', 'Unknown error')}")
            print()
            print("🤖 Agent Output:")
            print("-" * 80)
            print(result.get('agent_output', 'No output'))
            print("-" * 80)
            print()
        
        # Performance metrics
        print("=" * 80)
        print("📈 PERFORMANCE METRICS")
        print("=" * 80)
        print(f"Duration: {duration:.2f} seconds")
        print(f"Expected: < 120 seconds")
        print(f"Status: {'✅ PASS' if duration < 120 else '❌ FAIL'}")
        print()
        
        # Success criteria check
        print("=" * 80)
        print("✅ SUCCESS CRITERIA")
        print("=" * 80)
        
        criteria = {
            "Recon report generated": result.get('success', False),
            "No crashes or errors": result.get('success', False),
            "Completed within 2 minutes": duration < 120,
            "Documentation analyzed": len(result.get('documentation_found', [])) > 0,
        }
        
        all_passed = all(criteria.values())
        
        for criterion, passed in criteria.items():
            status = "✅ PASS" if passed else "❌ FAIL"
            print(f"{status} - {criterion}")
        
        print()
        print("=" * 80)
        print(f"OVERALL: {'✅ TEST PASSED' if all_passed else '❌ TEST FAILED'}")
        print("=" * 80)
        print()
        
        # Save detailed results
        results_file = "test_results_randy_recon.json"
        with open(results_file, 'w') as f:
            json.dump({
                "test": "Randy Recon E2E",
                "timestamp": datetime.now().isoformat(),
                "duration_seconds": duration,
                "success": result.get('success', False),
                "criteria_passed": all_passed,
                "result": result,
            }, f, indent=2)
        
        print(f"📝 Detailed results saved to: {results_file}")
        print()
        
        return all_passed
        
    except Exception as e:
        end_time = time.time()
        duration = end_time - start_time
        
        print()
        print("=" * 80)
        print("❌ TEST FAILED WITH EXCEPTION")
        print("=" * 80)
        print(f"Error: {str(e)}")
        print(f"Duration: {duration:.2f} seconds")
        print()
        
        import traceback
        print("Traceback:")
        print("-" * 80)
        traceback.print_exc()
        print("-" * 80)
        print()
        
        return False


if __name__ == "__main__":
    success = test_randy_recon()
    exit(0 if success else 1)
