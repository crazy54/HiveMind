# Strands Agent SDK - Quick Setup Guide

## What You Have

✅ **Packages Installed:**
- `strands-agents` (v1.9.1)
- `strands-agents-tools` (v0.2.8)

## What You Need

### Option 1: Bedrock API Key (Recommended for Quick Start)

1. **Get API Key:**
   - Visit: https://console.aws.amazon.com/bedrock
   - Navigate to: API keys → Generate long-term API key
   - Copy the key (shown only once!)
   - Valid for 30 days

2. **Enable Model Access:**
   - Bedrock Console → Model access → Manage model access
   - Enable "Claude 4 Sonnet" or your preferred model
   - Wait a few minutes for access to propagate

3. **Set Environment Variable:**
   ```bash
   export AWS_BEDROCK_API_KEY=your_bedrock_api_key_here
   ```

### Option 2: AWS Credentials (For Production)

```bash
aws configure
# OR
export AWS_ACCESS_KEY_ID=your_access_key
export AWS_SECRET_ACCESS_KEY=your_secret_key
export AWS_REGION=us-west-2
```

### Option 3: Other Providers

**Anthropic:**
```bash
pip install 'strands-agents[anthropic]'
export ANTHROPIC_API_KEY=your_key
```
Get key at: https://console.anthropic.com/

**OpenAI:**
```bash
pip install 'strands-agents[openai]'
export OPENAI_API_KEY=your_key
```
Get key at: https://platform.openai.com/api-keys

**Google Gemini:**
```bash
pip install 'strands-agents[gemini]'
export GOOGLE_API_KEY=your_key
```
Get key at: https://aistudio.google.com/apikey

## Example Files Created

1. **`my_first_agent.py`** - Basic agent with community tools
   - Calculator, Python REPL, HTTP requests
   - Tests calculations and conversation memory

2. **`custom_tool_example.py`** - Custom tool creation
   - Shows how to create your own tools
   - Weather and stock price examples
   - Combines custom and community tools

## Quick Start

1. **Set up credentials** (choose one option above)

2. **Run your first agent:**
   ```bash
   python my_first_agent.py
   ```

3. **Try custom tools:**
   ```bash
   python custom_tool_example.py
   ```

4. **Experiment interactively:**
   ```python
   from strands import Agent
   from strands_tools import calculator
   
   agent = Agent(tools=[calculator])
   response = agent("What is 25 * 47?")
   print(response)
   ```

## Key Concepts

- **Agent**: The main AI assistant that can use tools and maintain conversation context
- **Tools**: Functions the agent can call (built-in or custom)
- **System Prompt**: Instructions that guide the agent's behavior
- **Model**: The LLM provider (Bedrock, Anthropic, OpenAI, etc.)

## Tips

- **Temperature**: Lower (0.1-0.3) for factual tasks, higher (0.7-0.9) for creative
- **Tool Docstrings**: Always include clear docstrings - the model reads them!
- **Conversation Memory**: Agents automatically maintain context across messages
- **Max Tokens**: Set higher (2048+) if agent needs room for tool calls

## Troubleshooting

**"Access denied to model"**
→ Enable model access in Bedrock Console

**"Module not found"**
→ Install provider extension: `pip install 'strands-agents[provider]'`

**"Invalid API key"**
→ Check environment variable is set: `echo $AWS_BEDROCK_API_KEY`

**"Token limit exceeded"**
→ Increase `max_tokens` in model configuration

## Next Steps

1. Set up your credentials
2. Run the example files
3. Create your own custom tools
4. Build agents for your specific use cases!

## Documentation

For detailed documentation, use the Strands power's documentation search:
```python
# Search for specific topics
kiroPowers("strands", "strands-agents", "search_docs", {
    "query": "how to create custom tools",
    "k": 3
})

# Fetch complete documentation
kiroPowers("strands", "strands-agents", "fetch_doc", {
    "uri": "https://docs.strands.ai/user-guide/tools"
})
```

Happy agent building! 🤖
