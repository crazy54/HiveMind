# Repository Cloning in HiveMind

## Overview

When you run the `analyze` command, the system clones the GitHub/GitLab repository to your **local machine** (the same machine where you're running the CLI).

## Where Repositories Are Cloned

### Default Location
Repositories are cloned to: **`./analyzed_repos/<repo-name-timestamp>/`**

This is relative to where you run the CLI command from.

### Example
```bash
# If you run from /Users/you/hivemind-deploy
$ python -m src.cli analyze https://github.com/caddyserver/caddy

# Repository will be cloned to:
# /Users/you/hivemind-deploy/analyzed_repos/caddy-20241209-143022/
```

### Safe to Delete
The `analyzed_repos/` directory contains a README explaining that **all contents are safe to delete** after analysis. The cloned repositories are only needed during the analysis process.

## How It Works

### 1. Clone Operation
The git clone happens in `src/tools/repository.py`:

```python
def clone_repository(repo_url: str, local_path: str) -> str:
    """Clone a Git repository to a local directory."""
    # Create parent directory if it doesn't exist
    Path(local_path).parent.mkdir(parents=True, exist_ok=True)
    
    # Remove existing directory if it exists
    if os.path.exists(local_path):
        shutil.rmtree(local_path)
    
    # Clone the repository using GitPython
    Repo.clone_from(repo_url, local_path)
    return local_path
```

### 2. Tool Wrapper
The Strands tool wrapper in `src/tools/repository_tools.py`:

```python
@tool
def clone_repository(repo_url: str, local_path: str) -> str:
    """Clone a Git repository to a local directory."""
    return _clone_repository(repo_url, local_path)
```

### 3. Agent Usage
The Recon agent (`src/agents/strands_recon.py`) provides this tool to the Strands SDK agent, which then decides when and how to call it.

**The agent is supposed to provide the `local_path` parameter**, but currently it's not clear where that path is being set.

## Current Issue

The Strands Recon agent is timing out, and one potential issue is that **the agent needs to specify where to clone the repository**, but the tool requires a `local_path` parameter that the agent must provide.

### Expected Flow
1. User runs: `python -m src.cli analyze https://github.com/user/app`
2. CLI calls `run_recon_agent(repo_url, description)`
3. Recon agent creates a Strands Agent with the `clone_repository` tool
4. **Agent should call**: `clone_repository(repo_url, "./repos/temp-12345")`
5. Repository gets cloned to local disk
6. Agent reads documentation from cloned repo
7. Agent analyzes and returns results

### Problem
The Strands agent needs to:
1. Generate a temporary directory path
2. Pass it to the `clone_repository` tool
3. Use the same path for subsequent documentation reading tools

## Directory Structure After Cloning

```
hivemind-deploy/
├── analyzed_repos/              # Cloned repositories (safe to delete!)
│   ├── README.md               # Explains this directory
│   ├── caddy-20241209-143022/  # Example: analyzed repo
│   │   ├── README.md
│   │   ├── go.mod
│   │   └── ...
│   └── myapp-20241209-150133/  # Another analyzed repo
│       ├── package.json
│       ├── src/
│       └── ...
├── src/
│   ├── agents/
│   ├── tools/
│   └── ...
└── deployments/                # Deployment state files
```

## Cleanup

Currently, cloned repositories are **not automatically cleaned up**. They remain in the `./analyzed_repos/` directory.

**This is intentional** - the directory name makes it clear these are temporary analysis files that can be safely deleted.

### Manual Cleanup
```bash
# Remove all analyzed repositories
rm -rf analyzed_repos/*

# Keep the README
rm -rf analyzed_repos/*
# (The README is preserved by .gitignore)

# Remove specific clone
rm -rf analyzed_repos/caddy-20241209-143022/

# Check disk usage
du -sh analyzed_repos/
```

### Future Enhancement
Should implement automatic cleanup:
- After successful analysis
- After failed analysis
- On CLI exit
- With a `--cleanup` flag

## Security Considerations

### 1. Disk Space
Cloning large repositories can consume significant disk space. Consider:
- Shallow clones: `git clone --depth 1`
- Cleanup after analysis
- Disk space checks before cloning

### 2. Malicious Repositories
Cloning untrusted repositories could be risky:
- Don't execute code during analysis
- Only read documentation files
- Sandbox the clone directory
- Validate repository URLs

### 3. Credentials
If cloning private repositories:
- Use SSH keys or personal access tokens
- Don't store credentials in code
- Use environment variables or git credential helpers

## Configuration Options (Future)

Could add configuration for:

```python
# In config file or environment variables
CLONE_BASE_DIR = "./analyzed_repos"  # Where to clone repos
CLONE_CLEANUP = True                 # Auto-cleanup after analysis
CLONE_DEPTH = 1                      # Shallow clone depth
CLONE_TIMEOUT = 300                  # Timeout in seconds
```

## Comparison with Other Agents

### Compiler Agent
The Compiler agent also clones repositories:
```python
# In src/agents/strands_compiler.py
# Clones to: ./analyzed_repos/{deployment_id}
```

### Conductor Agent
The Conductor orchestrates all agents and manages the overall deployment directory structure:
```
./deployments/{deployment_id}/
├── state.json
├── logs/
└── artifacts/
```

## Best Practices

### 1. Use Unique Paths
Each clone should use a unique directory to avoid conflicts:
```python
from datetime import datetime
repo_name = repo_url.split('/')[-1].replace('.git', '')
timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
local_path = f"./analyzed_repos/{repo_name}-{timestamp}"
```

### 2. Clean Up After Use
```python
try:
    repo_path = clone_repository(repo_url, local_path)
    # ... do analysis ...
finally:
    shutil.rmtree(local_path, ignore_errors=True)
```

### 3. Handle Errors Gracefully
```python
try:
    repo_path = clone_repository(repo_url, local_path)
except RepositoryAnalysisError as e:
    print(f"Failed to clone: {e}")
    # Clean up partial clone
    shutil.rmtree(local_path, ignore_errors=True)
```

## Troubleshooting

### "Permission Denied" Error
```bash
# Check directory permissions
ls -la ./analyzed_repos/

# Fix permissions
chmod -R u+w ./analyzed_repos/
```

### "Directory Already Exists" Error
The clone function automatically removes existing directories, but if there's a permission issue:
```bash
# Manually remove
rm -rf ./analyzed_repos/caddy-20241209-143022/
```

### "Repository Not Found" Error
- Check the repository URL is correct
- Check if repository is private (requires authentication)
- Check network connectivity

### Disk Space Issues
```bash
# Check available space
df -h .

# Check analyzed_repos size
du -sh analyzed_repos/

# Clean up old clones
rm -rf analyzed_repos/*
```

## Summary

**Yes, the git clone happens on localhost** - the same machine where you run the CLI. The repository is cloned to `./analyzed_repos/<repo-name-timestamp>/` relative to your current working directory.

The cloned files remain on disk after analysis (currently no automatic cleanup). The directory name `analyzed_repos` makes it clear these are temporary files that **can be safely deleted at any time**. See `analyzed_repos/README.md` for details.
