#!/usr/bin/env python3
"""
Test script for SSH key management functionality.

This script tests SSH key generation, AWS import, and cleanup
without requiring a full deployment.
"""
import sys
import os
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from src.tools.ssh_keys import (
    generate_ssh_key_pair,
    import_key_to_aws,
    delete_key_from_aws,
    delete_local_keys,
    setup_deployment_keys,
    cleanup_deployment_keys,
    get_key_info,
)


def test_local_key_generation():
    """Test local SSH key generation without AWS."""
    print("=" * 60)
    print("TEST 1: Local SSH Key Generation")
    print("=" * 60)
    
    deployment_id = "test-local-123"
    key_dir = "./deployments"
    
    try:
        print(f"\n🔑 Generating SSH key pair for {deployment_id}...")
        key_info = generate_ssh_key_pair(deployment_id, key_dir)
        
        print(f"✅ Keys generated successfully!")
        print(f"   Private key: {key_info['private_key_path']}")
        print(f"   Public key: {key_info['public_key_path']}")
        print(f"   Key name: {key_info['key_name']}")
        
        # Verify files exist
        private_key_path = Path(key_info['private_key_path'])
        public_key_path = Path(key_info['public_key_path'])
        
        assert private_key_path.exists(), "Private key file not found"
        assert public_key_path.exists(), "Public key file not found"
        print(f"✅ Key files verified")
        
        # Check permissions
        private_perms = oct(private_key_path.stat().st_mode)[-3:]
        assert private_perms == "400", f"Private key permissions incorrect: {private_perms}"
        print(f"✅ Private key permissions correct (400)")
        
        # Cleanup
        print(f"\n🧹 Cleaning up local keys...")
        delete_local_keys(deployment_id, key_dir)
        
        assert not private_key_path.exists(), "Private key not deleted"
        assert not public_key_path.exists(), "Public key not deleted"
        print(f"✅ Local keys cleaned up")
        
        print(f"\n✅ TEST 1 PASSED\n")
        return True
        
    except Exception as e:
        print(f"\n❌ TEST 1 FAILED: {str(e)}\n")
        return False


def test_aws_key_management():
    """Test AWS key import and deletion (requires AWS credentials)."""
    print("=" * 60)
    print("TEST 2: AWS Key Management")
    print("=" * 60)
    
    deployment_id = "test-aws-456"
    key_dir = "./deployments"
    region = "us-east-1"
    
    try:
        # Check AWS credentials
        import boto3
        try:
            sts = boto3.client('sts')
            identity = sts.get_caller_identity()
            print(f"\n✅ AWS credentials found")
            print(f"   Account: {identity['Account']}")
            print(f"   User: {identity['Arn']}")
        except Exception as e:
            print(f"\n⚠️  AWS credentials not configured: {str(e)}")
            print(f"   Skipping AWS tests")
            print(f"\n⏭️  TEST 2 SKIPPED\n")
            return True
        
        print(f"\n🔑 Setting up deployment keys (local + AWS)...")
        key_info = setup_deployment_keys(deployment_id, region, key_dir)
        
        print(f"✅ Keys set up successfully!")
        print(f"   Private key: {key_info['private_key_path']}")
        print(f"   Public key: {key_info['public_key_path']}")
        print(f"   AWS key name: {key_info['aws_key_name']}")
        print(f"   Region: {key_info['region']}")
        
        # Verify in AWS
        ec2 = boto3.client('ec2', region_name=region)
        response = ec2.describe_key_pairs(KeyNames=[key_info['aws_key_name']])
        assert len(response['KeyPairs']) == 1, "Key not found in AWS"
        print(f"✅ Key verified in AWS EC2")
        
        # Cleanup
        print(f"\n🧹 Cleaning up deployment keys (local + AWS)...")
        results = cleanup_deployment_keys(deployment_id, region, key_dir)
        
        print(f"✅ Cleanup complete")
        print(f"   AWS deleted: {results['aws_deleted']}")
        print(f"   Local deleted: {results['local_deleted']}")
        
        if results['errors']:
            print(f"   Errors: {results['errors']}")
            return False
        
        # Verify deletion
        try:
            ec2.describe_key_pairs(KeyNames=[key_info['aws_key_name']])
            print(f"❌ Key still exists in AWS")
            return False
        except ec2.exceptions.ClientError as e:
            if 'InvalidKeyPair.NotFound' in str(e):
                print(f"✅ Key deleted from AWS")
            else:
                raise
        
        print(f"\n✅ TEST 2 PASSED\n")
        return True
        
    except Exception as e:
        print(f"\n❌ TEST 2 FAILED: {str(e)}\n")
        # Try to cleanup
        try:
            cleanup_deployment_keys(deployment_id, region, key_dir)
        except Exception:
            pass
        return False


def test_key_info_query():
    """Test querying existing key information."""
    print("=" * 60)
    print("TEST 3: Key Info Query")
    print("=" * 60)
    
    deployment_id = "test-query-789"
    key_dir = "./deployments"
    
    try:
        # Create keys
        print(f"\n🔑 Creating keys...")
        key_info = generate_ssh_key_pair(deployment_id, key_dir)
        print(f"✅ Keys created")
        
        # Query info
        print(f"\n🔍 Querying key info...")
        queried_info = get_key_info(deployment_id, key_dir)
        
        assert queried_info is not None, "Key info not found"
        assert queried_info['private_key_path'] == key_info['private_key_path']
        assert queried_info['public_key_path'] == key_info['public_key_path']
        assert queried_info['key_name'] == key_info['key_name']
        print(f"✅ Key info matches")
        
        # Query non-existent
        print(f"\n🔍 Querying non-existent key...")
        missing_info = get_key_info("non-existent-id", key_dir)
        assert missing_info is None, "Should return None for missing keys"
        print(f"✅ Returns None for missing keys")
        
        # Cleanup
        print(f"\n🧹 Cleaning up...")
        delete_local_keys(deployment_id, key_dir)
        print(f"✅ Cleaned up")
        
        print(f"\n✅ TEST 3 PASSED\n")
        return True
        
    except Exception as e:
        print(f"\n❌ TEST 3 FAILED: {str(e)}\n")
        # Try to cleanup
        try:
            delete_local_keys(deployment_id, key_dir)
        except Exception:
            pass
        return False


def main():
    """Run all tests."""
    print("\n" + "=" * 60)
    print("SSH KEY MANAGEMENT TEST SUITE")
    print("=" * 60 + "\n")
    
    results = []
    
    # Test 1: Local key generation
    results.append(("Local Key Generation", test_local_key_generation()))
    
    # Test 2: AWS key management (requires credentials)
    results.append(("AWS Key Management", test_aws_key_management()))
    
    # Test 3: Key info query
    results.append(("Key Info Query", test_key_info_query()))
    
    # Summary
    print("=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{test_name}: {status}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 All tests passed!")
        return 0
    else:
        print(f"\n⚠️  {total - passed} test(s) failed")
        return 1


if __name__ == "__main__":
    sys.exit(main())
