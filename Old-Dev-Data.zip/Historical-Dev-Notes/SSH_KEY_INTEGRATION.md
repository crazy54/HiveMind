# SSH Key Management Integration

## Overview

This document describes the SSH key management system integrated into the HiveMind AutoDeploy system. SSH keys are automatically generated, managed, and cleaned up as part of the deployment lifecycle.

## Implementation

### New Module: `src/tools/ssh_keys.py`

Complete SSH key management module with the following functions:

#### Key Generation
- `generate_ssh_key_pair(deployment_id, key_dir)` - Generates RSA 2048-bit key pair
- Uses cryptography library for secure key generation
- Saves private key as `.pem` file with 0400 permissions
- Saves public key in OpenSSH format

#### AWS Integration
- `import_key_to_aws(key_name, public_key_path, region)` - Imports public key to EC2
- `delete_key_from_aws(key_name, region)` - Removes key from EC2
- Handles existing keys by deleting and re-importing

#### Local Management
- `delete_local_keys(deployment_id, key_dir)` - Removes local key files
- Cleans up empty directories

#### Convenience Functions
- `setup_deployment_keys(deployment_id, region, key_dir)` - Complete setup (generate + import)
- `cleanup_deployment_keys(deployment_id, region, key_dir)` - Complete cleanup (AWS + local)
- `get_key_info(deployment_id, key_dir)` - Query existing key information

### Updated Modules

#### `src/tools/aws_infrastructure.py`
- Added `key_name` parameter to `create_ec2_instance()`
- EC2 instances now accept SSH key pair name
- Returns key_name in response for tracking

#### `src/tools/infrastructure_tools.py`
- Updated `create_ec2_instance()` wrapper to accept and pass `key_name`
- Tool now supports SSH key association

#### `src/tools/cleanup_tools.py`
- Enhanced `destroy_deployment()` to clean up SSH keys
- Calls `cleanup_deployment_keys()` after resource deletion
- Logs SSH key cleanup status

#### `src/agents/strands_conductor_workflow.py`
- Integrated SSH key generation in `deploy()` method
- Keys generated before infrastructure provisioning
- Keys cleaned up on deployment failure
- Skips key generation in dry-run mode

#### `requirements.txt`
- Added `cryptography` dependency for key generation

## Workflow Integration

### Deployment Flow

```
1. User initiates deployment
2. Conductor validates repository URL
3. Conductor generates SSH key pair
   ├─ Generate RSA 2048-bit key locally
   ├─ Save private key to deployments/{id}/autodeploy-{id}.pem
   ├─ Save public key to deployments/{id}/autodeploy-{id}.pub
   └─ Import public key to AWS EC2
4. Conductor starts workflow
5. Provisioner creates EC2 instance with key_name
6. Deployer uses private key for SSH access
7. Deployment completes
```

### Cleanup Flow

```
1. User initiates destroy or deployment fails
2. Conductor triggers resource cleanup
3. Cleanup tools delete AWS resources
4. Cleanup tools delete SSH keys
   ├─ Delete key pair from AWS EC2
   └─ Delete local key files
5. Cleanup completes
```

## Key Storage

### Directory Structure
```
deployments/
├── {deployment-id}/
│   ├── autodeploy-{deployment-id}.pem    # Private key (0400)
│   ├── autodeploy-{deployment-id}.pub    # Public key (0400)
│   └── {deployment-id}.json              # Deployment state
```

### Security
- Private keys stored with 0400 permissions (read-only for owner)
- Keys stored in deployment-specific directories
- Keys automatically cleaned up on destroy
- Keys never logged or exposed in state files

## AWS Integration

### Key Pair Naming
- Format: `autodeploy-{deployment-id}`
- Example: `autodeploy-a1b2c3d4-e5f6-7890-abcd-ef1234567890`

### EC2 Association
- Key name passed to `create_ec2_instance()`
- EC2 instance created with KeyName parameter
- Enables SSH access using private key

### Cleanup
- Key pair deleted from AWS on destroy
- Handles missing keys gracefully (already deleted)

## Error Handling

### Generation Failures
- Deployment fails immediately if key generation fails
- Error logged to deployment state
- No AWS resources created
- User receives clear error message

### Cleanup Failures
- Cleanup continues even if key deletion fails
- Errors logged but don't block resource cleanup
- User warned about manual cleanup if needed

### Partial Failures
- If AWS import fails, local keys are cleaned up
- If local cleanup fails, AWS keys still deleted
- Both operations attempted independently

## Usage Examples

### Manual Key Setup
```python
from src.tools.ssh_keys import setup_deployment_keys

# Generate and import keys
key_info = setup_deployment_keys(
    deployment_id="abc-123",
    region="us-east-1",
    key_dir="./deployments"
)

print(f"Private key: {key_info['private_key_path']}")
print(f"Public key: {key_info['public_key_path']}")
print(f"AWS key name: {key_info['aws_key_name']}")
```

### Manual Key Cleanup
```python
from src.tools.ssh_keys import cleanup_deployment_keys

# Clean up keys
results = cleanup_deployment_keys(
    deployment_id="abc-123",
    region="us-east-1",
    key_dir="./deployments"
)

print(f"AWS deleted: {results['aws_deleted']}")
print(f"Local deleted: {results['local_deleted']}")
if results['errors']:
    print(f"Errors: {results['errors']}")
```

### SSH Connection with Generated Key
```python
from src.tools.deployment import ssh_connect
from src.tools.ssh_keys import get_key_info

# Get key info
key_info = get_key_info("abc-123", "./deployments")

# Connect to EC2
client = ssh_connect(
    host="54.123.45.67",
    username="ec2-user",
    key_file=key_info['private_key_path']
)
```

## Testing

### Unit Tests Needed
- [ ] Test key generation
- [ ] Test AWS import/delete
- [ ] Test local file operations
- [ ] Test cleanup on failure
- [ ] Test permissions (0400)

### Integration Tests Needed
- [ ] Test full deployment with SSH keys
- [ ] Test SSH connection with generated keys
- [ ] Test key cleanup on destroy
- [ ] Test key cleanup on failure

## Security Considerations

### Best Practices Implemented
✅ Keys generated with strong algorithm (RSA 2048-bit)
✅ Private keys stored with restrictive permissions (0400)
✅ Keys automatically cleaned up
✅ Keys never logged or exposed
✅ Unique key per deployment

### Future Enhancements
- [ ] Support for existing SSH keys (user-provided)
- [ ] Key rotation support
- [ ] Key encryption at rest
- [ ] Key backup/recovery
- [ ] Support for ED25519 keys (more secure)

## Troubleshooting

### Key Generation Fails
**Symptom**: Deployment fails with "SSH key generation failed"
**Causes**:
- Insufficient disk space
- Permission issues in deployments directory
- Missing cryptography library

**Solutions**:
- Check disk space: `df -h`
- Check directory permissions: `ls -la deployments/`
- Install cryptography: `pip install cryptography`

### AWS Import Fails
**Symptom**: "Failed to import key to AWS"
**Causes**:
- Invalid AWS credentials
- Insufficient IAM permissions
- Region not available

**Solutions**:
- Verify credentials: `aws sts get-caller-identity`
- Check IAM permissions (need `ec2:ImportKeyPair`)
- Verify region: `aws ec2 describe-regions`

### SSH Connection Fails
**Symptom**: "Authentication failed" or "Connection refused"
**Causes**:
- Wrong key file
- Key permissions too open
- Security group blocks SSH
- Instance not ready

**Solutions**:
- Verify key path: `ls -la deployments/{id}/*.pem`
- Fix permissions: `chmod 400 deployments/{id}/*.pem`
- Check security group allows port 22
- Wait for instance to be running

### Cleanup Fails
**Symptom**: "SSH key cleanup failed"
**Causes**:
- Key already deleted
- AWS credentials expired
- File system issues

**Solutions**:
- Check if key exists: `aws ec2 describe-key-pairs`
- Refresh credentials: `aws configure`
- Check file system: `ls -la deployments/{id}/`

## Related Documentation

- [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md) - Overall implementation status
- [RESOURCE_TRACKING.md](RESOURCE_TRACKING.md) - Resource tracking system
- [CLEANUP_SUMMARY.md](CLEANUP_SUMMARY.md) - Cleanup implementation
- [TESTING_GUIDE.md](TESTING_GUIDE.md) - Testing guide

## Next Steps

1. **Test SSH Key Integration**
   - Deploy test application
   - Verify SSH connection works
   - Test key cleanup

2. **Add Load Balancer Support**
   - Update provisioner to detect web services
   - Call create_load_balancer for web apps
   - Register instances with target groups

3. **Enhance Security Operations**
   - Real SSL certificate provisioning
   - AWS Inspector integration
   - Enhanced OS hardening

4. **Real AWS Testing**
   - Create integration tests
   - Test with real AWS account
   - Verify end-to-end workflow

## Summary

SSH key management is now fully integrated into the HiveMind AutoDeploy system. Keys are automatically generated, imported to AWS, used for EC2 access, and cleaned up on destroy. This enables secure, automated SSH access to deployed instances without manual key management.

**Status**: ✅ Complete and ready for testing
