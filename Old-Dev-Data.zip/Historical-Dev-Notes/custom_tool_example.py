#!/usr/bin/env python3
"""
Custom Tool Example - Shows how to create your own tools

This demonstrates:
1. Creating custom tools with the @tool decorator
2. Using tools with clear docstrings
3. Combining custom and community tools
"""

from strands import Agent, tool
from strands_tools import calculator
import random

@tool
def get_weather(location: str) -> str:
    """Get current weather for a location.
    
    Args:
        location: City name (e.g., "San Francisco", "New York")
    
    Returns:
        Weather information as a string
    """
    # Simulated weather data
    conditions = ["Sunny", "Cloudy", "Rainy", "Partly Cloudy"]
    temp = random.randint(50, 85)
    condition = random.choice(conditions)
    return f"Weather in {location}: {condition}, {temp}°F"

@tool
def get_stock_price(symbol: str) -> str:
    """Get current stock price for a symbol.
    
    Args:
        symbol: Stock ticker symbol (e.g., "AAPL", "GOOGL")
    
    Returns:
        Stock price information as a string
    """
    # Simulated stock data
    price = random.uniform(100, 500)
    change = random.uniform(-5, 5)
    return f"{symbol}: ${price:.2f} ({change:+.2f}%)"

def main():
    # Create agent with custom and community tools
    agent = Agent(
        tools=[get_weather, get_stock_price, calculator],
        system_prompt="You are a helpful assistant with access to weather, stock prices, and calculations."
    )
    
    print("🤖 Agent with custom tools created!")
    print("\n" + "="*60)
    print("Testing custom tools...")
    print("="*60 + "\n")
    
    # Test weather tool
    response = agent("What's the weather like in San Francisco?")
    print(f"Q: What's the weather like in San Francisco?")
    print(f"A: {response}\n")
    
    # Test stock tool
    response = agent("What's the current price of AAPL stock?")
    print(f"Q: What's the current price of AAPL stock?")
    print(f"A: {response}\n")
    
    # Test combining tools
    response = agent("If AAPL is at $150 and I buy 10 shares, how much do I spend?")
    print(f"Q: If AAPL is at $150 and I buy 10 shares, how much do I spend?")
    print(f"A: {response}\n")
    
    print("="*60)
    print("✅ Custom tools working perfectly!")
    print("="*60)

if __name__ == "__main__":
    main()
