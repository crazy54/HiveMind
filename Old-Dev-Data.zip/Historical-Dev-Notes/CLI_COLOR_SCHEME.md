# CLI Color Scheme

This document describes the color scheme used in HiveMind's CLI output for better readability and scanning.

## Color Palette

### Workflow Output Colors

| Element | Color | Purpose |
|---------|-------|---------|
| **Section Headers** (`##`, `###`) | Green | Main sections like "Workflow Overview", "Task Sequence" |
| **Field Labels** (Repository:, Deployment:, etc.) | Light Yellow/Pale Yellow | Key-value pair labels |
| **Agent Names** (**Recon**, **Compile**, etc.) | Cyan | Specialist agent names in task lists |
| **Dependencies** ("Depends on:") | Red (label) + Yellow (name) | Task dependencies - highly visible |
| **Role** field | Blue | Agent role descriptions |
| **Timeout** field | Orange | Timeout values |
| **Tools** field | Light Blue | Tool listings |
| **Focus** field | Magenta | Focus area descriptions |
| **Priority** field | Orange | Priority values |

### Status Colors

| Element | Color | Purpose |
|---------|-------|---------|
| Success messages | Green | Successful operations |
| Error messages | Red | Failures and errors |
| Warnings | Yellow | Warnings and what-if mode |
| Info | Cyan | General information |
| Actions | Orange | Actions being performed |

## Examples

### Workflow Overview
```
## Workflow Overview          <- GREEN
Repository: https://...       <- "Repository:" in LIGHT_YELLOW
Deployment ID: abc123         <- "Deployment ID:" in LIGHT_YELLOW
Region: us-east-1            <- "Region:" in LIGHT_YELLOW
```

### Task with Dependencies
```
### 2. Compile (Depends on: Recon)
     ^CYAN^              ^RED^  ^YELLOW^
     
Role: Application build       <- "Role:" in BLUE
Timeout: 15 minutes          <- "Timeout:" in ORANGE
Tools: Python REPL           <- "Tools:" in LIGHT_BLUE
Focus: Build process         <- "Focus:" in MAGENTA
```

## Implementation

Colors are applied through the `format_workflow_output()` function in `src/utils/colors.py`.

### Key Features

1. **Automatic Detection**: Colors are automatically applied to workflow output
2. **Pattern Matching**: Uses regex to identify and colorize specific patterns
3. **Markdown Cleanup**: Removes markdown bold markers (`**`) while applying colors
4. **Terminal Support**: Respects `NO_COLOR` and `FORCE_COLOR` environment variables

### Usage in Code

```python
from src.utils.colors import format_workflow_output

# Format agent/workflow output before printing
formatted_text = format_workflow_output(raw_text)
print(formatted_text)
```

## Benefits

1. **Quick Scanning**: Colors help users quickly identify sections and key information
2. **Dependency Visibility**: Red "Depends on:" with yellow dependency names makes relationships obvious
3. **Consistent Experience**: Same color scheme across all CLI output
4. **Accessibility**: Can be disabled with `NO_COLOR=1` environment variable

## Disabling Colors

To disable colors:
```bash
NO_COLOR=1 python3 -m src.cli deploy ...
```

Or in code:
```python
from src.utils.colors import disable_colors
disable_colors()
```

## Future Enhancements

Potential improvements:
- Add color customization via config file
- Support for different color themes (light/dark mode)
- More granular control over which elements are colored
- Color-blind friendly palette option

## Known Issues & Fixes

### Strands Tool Warnings (FIXED)

**Issue**: The Strands SDK generates warnings when the LLM tries to call tools that don't exist:
```
Tool 'httprequest' not found in parent agent's tool registry
Tool 'fileread' not found in parent agent's tool registry
```

**Cause**: The LLM sometimes tries to call generic tools that aren't registered with the specific agent.

**Solution**: These warnings are automatically filtered out by `format_workflow_output()` since they don't affect functionality - they're just informational messages from the SDK.

**Result**: Clean output without warning noise cluttering the deployment logs.
