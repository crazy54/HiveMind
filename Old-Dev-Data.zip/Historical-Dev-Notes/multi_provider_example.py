#!/usr/bin/env python3
"""
Multi-Provider Example - Shows how to use different LLM providers

This demonstrates switching between:
- Amazon Bedrock (default)
- Anthropic (direct)
- OpenAI
- Google Gemini
- Meta Llama

Uncomment the provider you want to use and ensure you have:
1. Installed the provider extension
2. Set the appropriate API key
"""

from strands import Agent
from strands_tools import calculator
import os

def create_bedrock_agent():
    """Amazon Bedrock - Default provider, no extra installation needed"""
    print("Creating Bedrock agent...")
    
    # Simplest - uses default Claude 4 Sonnet
    agent = Agent(
        tools=[calculator],
        system_prompt="You are a helpful math assistant."
    )
    
    # Or specify model explicitly
    # from strands.models import BedrockModel
    # model = BedrockModel(
    #     model_id="anthropic.claude-sonnet-4-20250514-v1:0",
    #     temperature=0.7,
    #     max_tokens=2048
    # )
    # agent = Agent(model=model, tools=[calculator])
    
    return agent

def create_anthropic_agent():
    """Anthropic Direct - Requires: pip install 'strands-agents[anthropic]'"""
    print("Creating Anthropic agent...")
    
    from strands.models.anthropic import AnthropicModel
    
    model = AnthropicModel(
        client_args={"api_key": os.environ.get("ANTHROPIC_API_KEY")},
        model_id="claude-sonnet-4-20250514",
        max_tokens=2048,
        params={"temperature": 0.7}
    )
    
    agent = Agent(
        model=model,
        tools=[calculator],
        system_prompt="You are a helpful math assistant."
    )
    
    return agent

def create_openai_agent():
    """OpenAI - Requires: pip install 'strands-agents[openai]'"""
    print("Creating OpenAI agent...")
    
    from strands.models.openai import OpenAIModel
    
    model = OpenAIModel(
        client_args={"api_key": os.environ.get("OPENAI_API_KEY")},
        model_id="gpt-5-mini",
    )
    
    agent = Agent(
        model=model,
        tools=[calculator],
        system_prompt="You are a helpful math assistant."
    )
    
    return agent

def create_gemini_agent():
    """Google Gemini - Requires: pip install 'strands-agents[gemini]'"""
    print("Creating Gemini agent...")
    
    from strands.models.gemini import GeminiModel
    
    model = GeminiModel(
        client_args={"api_key": os.environ.get("GOOGLE_API_KEY")},
        model_id="gemini-2.5-pro",
    )
    
    agent = Agent(
        model=model,
        tools=[calculator],
        system_prompt="You are a helpful math assistant."
    )
    
    return agent

def create_llama_agent():
    """Meta Llama - Requires: pip install 'strands-agents[llamaapi]'"""
    print("Creating Llama agent...")
    
    from strands.models.llamaapi import LlamaAPIModel
    
    model = LlamaAPIModel(
        client_args={"api_key": os.environ.get("LLAMA_API_KEY")},
        model_id="Llama-4-Maverick-17B-128E-Instruct-FP8",
        temperature=0.7,
        max_completion_tokens=2048
    )
    
    agent = Agent(
        model=model,
        tools=[calculator],
        system_prompt="You are a helpful math assistant."
    )
    
    return agent

def main():
    print("="*60)
    print("Multi-Provider Agent Example")
    print("="*60 + "\n")
    
    # Choose your provider (uncomment one)
    agent = create_bedrock_agent()  # Default - no extra setup needed
    # agent = create_anthropic_agent()  # Requires ANTHROPIC_API_KEY
    # agent = create_openai_agent()     # Requires OPENAI_API_KEY
    # agent = create_gemini_agent()     # Requires GOOGLE_API_KEY
    # agent = create_llama_agent()      # Requires LLAMA_API_KEY
    
    print("\n" + "="*60)
    print("Testing agent with a calculation...")
    print("="*60 + "\n")
    
    response = agent("What is 234 * 567?")
    print(f"Question: What is 234 * 567?")
    print(f"Answer: {response}\n")
    
    print("="*60)
    print("✅ Agent working successfully!")
    print("="*60)

if __name__ == "__main__":
    main()
