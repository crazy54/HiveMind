#!/usr/bin/env python3
"""
My First Strands Agent - A simple example to get started

This agent uses Amazon Bedrock (default) with community tools.
Before running, set up your credentials:

Option 1 - Bedrock API Key (Quick Start):
  export AWS_BEDROCK_API_KEY=your_bedrock_api_key
  Get one at: https://console.aws.amazon.com/bedrock → API keys

Option 2 - AWS Credentials (Production):
  aws configure
  OR
  export AWS_ACCESS_KEY_ID=your_access_key
  export AWS_SECRET_ACCESS_KEY=your_secret_key
  export AWS_REGION=us-west-2

Don't forget to enable model access in Bedrock Console!
"""

from strands import Agent
from strands_tools import calculator, python_repl, http_request

def main():
    # Create an agent with community tools
    # Uses Bedrock Claude 4 Sonnet by default
    agent = Agent(
        tools=[calculator, python_repl, http_request],
        system_prompt="You are a helpful assistant with access to tools for calculations, code execution, and web requests."
    )
    
    print("🤖 Agent created successfully!")
    print("\n" + "="*60)
    print("Testing the agent with a simple calculation...")
    print("="*60 + "\n")
    
    # Test with a calculation
    response = agent("What is 157 * 89?")
    print(f"Question: What is 157 * 89?")
    print(f"Answer: {response}\n")
    
    # Test conversation memory
    print("="*60)
    print("Testing conversation memory...")
    print("="*60 + "\n")
    
    agent("My favorite color is blue")
    response = agent("What's my favorite color?")
    print(f"Question: What's my favorite color?")
    print(f"Answer: {response}\n")
    
    print("="*60)
    print("✅ Agent is working! Try asking it your own questions.")
    print("="*60)

if __name__ == "__main__":
    main()
