# What-If Mode (Dry-Run) 🔮

## Overview

What-If mode allows you to **simulate a deployment without making any actual changes** to your AWS infrastructure or applications. This is perfect for:

- Testing deployment configurations
- Estimating costs before deploying
- Understanding what resources will be created
- Validating deployment plans
- Training and demonstrations

## How It Works

When you use `--what-if` mode, HiveMind:

1. ✅ **Analyzes** your repository (Recon + Compiler)
2. ✅ **Plans** infrastructure (Provisioner)
3. ✅ **Simulates** deployment (Deployer)
4. ✅ **Predicts** security hardening (Sheriff)
5. ❌ **Does NOT** create any AWS resources
6. ❌ **Does NOT** make any actual changes
7. ✅ **Generates** predictions and estimates

## Usage

### CLI

```bash
# What-if mode
python -m src.cli deploy https://github.com/user/app "Deploy my app" --what-if

# Real deployment (after reviewing what-if results)
python -m src.cli deploy https://github.com/user/app "Deploy my app"
```

### Python API

```python
from src.agents.strands_conductor import StrandsConductorAgent

conductor = StrandsConductorAgent()

# What-if mode
result = conductor.deploy(
    repo_url="https://github.com/user/app",
    description="Deploy my application",
    dry_run=True  # What-if mode!
)

# Check predictions
if result.success:
    print(f"Monthly cost: ${result.state.predicted_costs['total_monthly']:.2f}")
    print(f"Resources: {result.state.predicted_resources}")
    print(f"Timeline: {result.state.predicted_timeline['total']}")
```

## What You Get

### 1. Cost Predictions 💰

```
Estimated Monthly Cost: $45.67
  - EC2: $15.18/month ($0.0208/hour)
  - RDS: $12.41/month ($0.0170/hour)
  - Data Transfer: $10.00/month
```

Includes:
- EC2 instance costs (based on instance type)
- RDS database costs (if database detected)
- Data transfer estimates
- Hourly and monthly breakdowns

### 2. Resource Predictions 🏗️

```
Resources to be Created:
  - VPC: 1
  - Subnets: 2 (public + private)
  - Security Groups: 1
  - EC2 Instances: 1
  - RDS Instances: 1 (if database required)
```

Shows exactly what AWS resources would be created.

### 3. Timeline Predictions ⏱️

```
Estimated Timeline:
  - Total: 13-27 minutes
  - Recon: 30-60 seconds
  - Compilation: 2-5 minutes
  - Provisioning: 3-5 minutes
  - Deployment: 3-7 minutes
  - Security: 5-10 minutes
```

Helps you plan deployment windows.

### 4. Tech Stack Analysis 🔧

```
Tech Stack Detected:
  - Language: Node.js
  - Framework: Express
  - Runtime: 18.x
  - Database: PostgreSQL 14
```

Confirms what was detected from your repository.

### 5. Deployment Plan 📋

Complete analysis from Recon agent:
- Required services
- Environment variables
- Deployment steps
- Recommendations

## Example Output

```bash
$ python -m src.cli deploy https://github.com/user/app "Deploy app" --what-if

🔮 WHAT-IF MODE: Simulating deployment (no actual changes will be made)
Repository: https://github.com/user/app
Description: Deploy app

✅ What-if analysis complete!
Deployment ID: abc123-def456-ghi789

Status: dry_run

💰 Predicted Monthly Costs:
  Total: $45.67/month
  EC2: $15.18/month
  RDS: $12.41/month
  Data Transfer: $10.00/month

🏗️  Resources That Would Be Created:
  VPC: 1
  Subnets: 2
  Security Groups: 1
  EC2 Instances: 1
  RDS Instances: 1

⏱️  Estimated Timeline:
  Total: 13-27 minutes

📝 Logs (10 entries):
  [2025-12-08T13:30:00] 🔮 WHAT-IF MODE: Simulating deployment
  [2025-12-08T13:30:01] 🔍 HiveMind SA analyzing documentation...
  [2025-12-08T13:30:05] ✅ HiveMind SA: Deployment plan created
  [2025-12-08T13:30:06] 🔨 HiveMind DevOps analyzing repository...
  [2025-12-08T13:30:15] ✅ HiveMind DevOps: Build successful
  [2025-12-08T13:30:16] ☁️  HiveMind SysEng planning infrastructure...
  [2025-12-08T13:30:20] ✅ HiveMind SysEng: Plan created
  [2025-12-08T13:30:21] 🔮 WHAT-IF MODE: Generating predictions...
  [2025-12-08T13:30:22] 📊 WHAT-IF PREDICTIONS: [details above]
  [2025-12-08T13:30:23] ✅ What-if analysis complete. No actual resources were created.
```

## Workflow

### Recommended Process

1. **Run What-If First**
   ```bash
   python -m src.cli deploy <repo> "Description" --what-if
   ```

2. **Review Predictions**
   - Check estimated costs
   - Verify resources to be created
   - Review timeline
   - Check tech stack detection

3. **Make Adjustments** (if needed)
   - Update repository configuration
   - Adjust instance types
   - Modify database requirements

4. **Run Real Deployment**
   ```bash
   python -m src.cli deploy <repo> "Description"
   ```

## Use Cases

### 1. Cost Estimation

Before deploying, see how much it will cost:

```bash
# Check cost for different configurations
python -m src.cli deploy <repo> "Small instance" --what-if
# Review cost, then try larger instance
python -m src.cli deploy <repo> "Large instance" --what-if
```

### 2. Training & Demos

Demonstrate the system without creating resources:

```bash
# Safe for demos - no AWS charges
python -m src.cli deploy <demo-repo> "Demo deployment" --what-if
```

### 3. CI/CD Validation

Validate deployment configurations in CI:

```bash
# In CI pipeline
python -m src.cli deploy $REPO_URL "CI validation" --what-if
# Check exit code and predictions
```

### 4. Multi-Environment Planning

Plan deployments for different environments:

```bash
# Dev environment
python -m src.cli deploy <repo> "Dev deployment" --what-if --region us-east-1

# Prod environment
python -m src.cli deploy <repo> "Prod deployment" --what-if --region us-west-2
```

## Limitations

What-If mode **cannot** predict:

1. **Exact AWS costs** - Estimates are based on standard pricing
2. **Network performance** - Actual latency and throughput
3. **Application behavior** - Runtime issues or bugs
4. **Third-party services** - External API costs or limits
5. **Data transfer costs** - Actual usage patterns

What-If mode **does not**:

1. Create any AWS resources
2. Clone repositories to AWS
3. Install any software
4. Configure any services
5. Make any network changes
6. Charge any AWS costs

## State Persistence

What-if deployments are saved with `dry_run: true` flag:

```python
# Load what-if deployment
conductor = StrandsConductorAgent()
state = conductor.get_status(deployment_id)

if state.dry_run:
    print("This was a what-if simulation")
    print(f"Predicted cost: ${state.predicted_costs['total_monthly']:.2f}")
```

## Comparison: What-If vs Real

| Feature | What-If Mode | Real Deployment |
|---------|--------------|-----------------|
| Analyzes repo | ✅ Yes | ✅ Yes |
| Detects tech stack | ✅ Yes | ✅ Yes |
| Creates AWS resources | ❌ No | ✅ Yes |
| Deploys application | ❌ No | ✅ Yes |
| Configures security | ❌ No | ✅ Yes |
| Generates predictions | ✅ Yes | ❌ No |
| AWS charges | ❌ No | ✅ Yes |
| Time required | ~1-2 min | ~13-27 min |

## Best Practices

### 1. Always What-If First

```bash
# Good practice
python -m src.cli deploy <repo> "Deploy" --what-if  # Check first
python -m src.cli deploy <repo> "Deploy"            # Then deploy

# Risky
python -m src.cli deploy <repo> "Deploy"  # Deploying blind!
```

### 2. Review All Predictions

Don't just check cost - review:
- Resources to be created
- Timeline estimates
- Tech stack detection
- Deployment plan

### 3. Save What-If Results

```bash
# Save output for review
python -m src.cli deploy <repo> "Deploy" --what-if > what-if-results.txt

# Review later
cat what-if-results.txt
```

### 4. Use in CI/CD

```yaml
# .github/workflows/deploy.yml
- name: Validate deployment
  run: |
    python -m src.cli deploy $REPO_URL "Validation" --what-if
    # Check predictions meet requirements
```

### 5. Document Decisions

Keep what-if results as documentation:

```bash
# Before major deployment
python -m src.cli deploy <repo> "Production v2.0" --what-if > docs/deployment-plan-v2.0.txt
```

## Troubleshooting

### What-If Takes Too Long

What-if should be fast (1-2 minutes). If slow:
- Check network connection
- Verify repository is accessible
- Check Strands SDK configuration

### Predictions Seem Wrong

Predictions are estimates. They may be inaccurate if:
- Repository has non-standard structure
- Custom infrastructure requirements
- Special AWS configurations needed

### Want More Detail

Use verbose logging:

```python
import logging
logging.basicConfig(level=logging.DEBUG)

conductor.deploy(repo_url, description, dry_run=True)
```

## Examples

See `example_what_if.py` for complete examples:

```bash
python example_what_if.py
```

## Summary

What-If mode is your **safety net** for deployments:

✅ **Safe** - No actual changes
✅ **Fast** - Results in 1-2 minutes  
✅ **Informative** - Costs, resources, timeline
✅ **Flexible** - Test different configurations
✅ **Free** - No AWS charges

**Always use `--what-if` before deploying to production!**

---

**Next Steps:**
- Try `python example_what_if.py`
- Read `NEXT_STEPS.md` for deployment guide
- See `README.md` for full documentation
