#!/usr/bin/env python3
"""
End-to-End Test for Chris Compiler Agent
Tests tech stack detection and build process against hello-world-repo
"""
import time
import json
import os
from datetime import datetime
from src.agents.strands_compiler import run_compiler_agent


def test_chris_compiler():
    """Run Chris Compiler E2E test"""
    print("=" * 80)
    print("🔨 CHRIS COMPILER - END-TO-END TEST")
    print("=" * 80)
    print()
    
    # Test configuration
    repo_path = "./hello-world-repo"
    deployment_id = "test-compiler-e2e"
    
    print(f"📋 Test Configuration:")
    print(f"   Repository: {repo_path}")
    print(f"   Deployment ID: {deployment_id}")
    print(f"   Target Path: ./repos/{deployment_id}")
    print()
    
    # Start timing
    start_time = time.time()
    print(f"⏱️  Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Run Chris Compiler
    print("🚀 Running Chris Compiler...")
    print("-" * 80)
    
    try:
        result = run_compiler_agent(
            repo_url=repo_path,
            deployment_id=deployment_id
        )
        
        # End timing
        end_time = time.time()
        duration = end_time - start_time
        
        print()
        print("-" * 80)
        print(f"⏱️  End Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"⏱️  Duration: {duration:.2f} seconds")
        print()
        
        # Display results
        print("=" * 80)
        print("📊 TEST RESULTS")
        print("=" * 80)
        print()
        
        print(f"✅ Success: {result.get('success', False)}")
        print()
        
        if result.get('success'):
            print("🔧 Tool Calls:")
            tool_calls = result.get('tool_calls', [])
            if tool_calls:
                for i, call in enumerate(tool_calls, 1):
                    print(f"   {i}. {call.get('tool', 'Unknown')}")
                    tool_result = call.get('result', {})
                    if isinstance(tool_result, dict):
                        for key, value in tool_result.items():
                            if key != 'output':  # Skip verbose output
                                print(f"      - {key}: {value}")
            else:
                print("   - No tool calls recorded")
            print()
            
            print("🤖 Agent Response:")
            print("-" * 80)
            print(result.get('response', 'No response'))
            print("-" * 80)
            print()
            
        else:
            print(f"❌ Error: {result.get('error', 'Unknown error')}")
            print()
            print("🤖 Agent Response:")
            print("-" * 80)
            print(result.get('response', 'No response'))
            print("-" * 80)
            print()
        
        # Check for build artifacts
        print("=" * 80)
        print("📦 BUILD ARTIFACTS CHECK")
        print("=" * 80)
        
        target_path = f"./repos/{deployment_id}"
        artifacts_found = os.path.exists(target_path)
        
        if artifacts_found:
            print(f"✅ Target directory exists: {target_path}")
            try:
                files = os.listdir(target_path)
                print(f"   Files found: {len(files)}")
                for file in files[:10]:  # Show first 10 files
                    print(f"   - {file}")
                if len(files) > 10:
                    print(f"   ... and {len(files) - 10} more files")
            except Exception as e:
                print(f"   ⚠️  Could not list files: {e}")
        else:
            print(f"❌ Target directory not found: {target_path}")
        print()
        
        # Performance metrics
        print("=" * 80)
        print("📈 PERFORMANCE METRICS")
        print("=" * 80)
        print(f"Duration: {duration:.2f} seconds")
        print(f"Expected: < 120 seconds")
        print(f"Status: {'✅ PASS' if duration < 120 else '❌ FAIL'}")
        print()
        
        # Success criteria check
        print("=" * 80)
        print("✅ SUCCESS CRITERIA")
        print("=" * 80)
        
        # Parse response for tech stack detection
        response_text = result.get('response', '').lower()
        tech_stack_detected = 'python' in response_text or 'tech stack' in response_text
        build_attempted = 'build' in response_text or 'compile' in response_text
        
        criteria = {
            "Agent completed successfully": result.get('success', False),
            "No crashes or errors": result.get('success', False),
            "Completed within 2 minutes": duration < 120,
            "Tech stack detection attempted": tech_stack_detected,
            "Build process attempted": build_attempted or artifacts_found,
        }
        
        all_passed = all(criteria.values())
        
        for criterion, passed in criteria.items():
            status = "✅ PASS" if passed else "❌ FAIL"
            print(f"{status} - {criterion}")
        
        print()
        print("=" * 80)
        print(f"OVERALL: {'✅ TEST PASSED' if all_passed else '❌ TEST FAILED'}")
        print("=" * 80)
        print()
        
        # Save detailed results
        results_file = "test_results_chris_compiler.json"
        with open(results_file, 'w') as f:
            json.dump({
                "test": "Chris Compiler E2E",
                "timestamp": datetime.now().isoformat(),
                "duration_seconds": duration,
                "success": result.get('success', False),
                "criteria_passed": all_passed,
                "artifacts_found": artifacts_found,
                "result": result,
            }, f, indent=2)
        
        print(f"📝 Detailed results saved to: {results_file}")
        print()
        
        return all_passed
        
    except Exception as e:
        end_time = time.time()
        duration = end_time - start_time
        
        print()
        print("=" * 80)
        print("❌ TEST FAILED WITH EXCEPTION")
        print("=" * 80)
        print(f"Error: {str(e)}")
        print(f"Duration: {duration:.2f} seconds")
        print()
        
        import traceback
        print("Traceback:")
        print("-" * 80)
        traceback.print_exc()
        print("-" * 80)
        print()
        
        return False


if __name__ == "__main__":
    success = test_chris_compiler()
    exit(0 if success else 1)
