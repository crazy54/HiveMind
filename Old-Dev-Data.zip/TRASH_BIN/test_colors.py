#!/usr/bin/env python3
"""Test script to demonstrate colored CLI output."""

from src.utils.colors import (
    tool, action, failure, tool_call, success, info, warning,
    format_agent_output
)

print("=" * 70)
print("HiveMind CLI Color Test")
print("=" * 70)
print()

# Test basic colors
print(info("🔍 Info message (cyan)"))
print(success("✅ Success message (green)"))
print(failure("❌ Failure message (red)"))
print(warning("⚠️  Warning message (yellow)"))
print(tool("🔧 Tool name (light blue)"))
print(action("🚀 Action verb (orange)"))
print(tool_call("Tool #1: clone_repository (yellow)"))
print()

# Test formatted agent output
print("=" * 70)
print("Formatted Agent Output Example:")
print("=" * 70)
print()

sample_output = """
I'll analyze the Caddy server repository and create a comprehensive deployment plan.

Tool #1: clone_repository
Cloning repository to analyze its structure...

Tool #2: read_repository_documentation
Reading documentation files to understand requirements...

Tool #3: analyze_environment_variables
Extracting environment variables from configuration...

Tool #4: identify_required_services
Identifying required services like databases and caches...

Tool #5: generate_deployment_plan
Generating comprehensive deployment plan...

Analysis complete! Found the following:
- Language: Go
- Framework: Caddy Web Server
- Database: None required
- Services: None required

Error: Could not find requirements.txt
Failed to parse configuration file
"""

formatted = format_agent_output(sample_output)
print(formatted)

print()
print("=" * 70)
print("Color Legend:")
print("=" * 70)
print(f"  {tool('Light Blue')} = Tools and tool names")
print(f"  {action('Orange')} = Actions and verbs")
print(f"  {failure('Red')} = Failures and errors")
print(f"  {tool_call('Yellow')} = Tool calls (Tool #N: action)")
print(f"  {success('Green')} = Success messages")
print(f"  {info('Cyan')} = Info messages")
print(f"  {warning('Yellow')} = Warnings")
print()
