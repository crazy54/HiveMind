"""Recon Agent - Repository reconnaissance and deployment planning.

Original implementation (reference) - see strands_recon.py for production version.
"""
from typing import Dict, Any, Optional
from src.tools.repository import clone_repository as core_clone_repository
from src.tools.documentation import (
    read_documentation_files,
    extract_environment_variables,
    extract_service_requirements,
    extract_deployment_steps,
    extract_port_requirements,
    extract_domain_requirements,
    analyze_docker_configuration,
    create_deployment_plan,
)


class ReconAgent:
    """
    Recon Agent - Analyzes repositories and creates deployment plans.
    
    Responsibilities:
    - Read and parse documentation (README, DEPLOY, etc.)
    - Extract service requirements (databases, caches, queues)
    - Identify environment variables
    - Extract deployment steps
    - Create comprehensive deployment plan
    """
    
    def __init__(self):
        """Initialize Recon Agent."""
        self.name = "HiveMind Recon"
    
    def analyze_repository(
        self,
        repo_url: str,
        description: str,
        tech_stack: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Analyze repository and create deployment plan.
        
        Args:
            repo_url: GitHub repository URL
            description: User's description of deployment
            tech_stack: Optional tech stack from Compiler
            
        Returns:
            Dictionary with deployment plan and requirements
        """
        try:
            # Clone repository
            clone_result = core_clone_repository(repo_url)
            if not clone_result["success"]:
                return {
                    "success": False,
                    "error": f"Failed to clone repository: {clone_result.get('error')}",
                }
            
            repo_path = clone_result["repo_path"]
            
            # Read all documentation
            doc_content = read_documentation_files(repo_path)
            
            if not doc_content:
                return {
                    "success": False,
                    "error": "No documentation files found in repository",
                    "repo_path": repo_path,
                }
            
            # Extract all requirements
            env_vars = extract_environment_variables(doc_content)
            services = extract_service_requirements(doc_content)
            steps = extract_deployment_steps(doc_content)
            ports = extract_port_requirements(doc_content)
            domain_reqs = extract_domain_requirements(doc_content)
            docker_config = analyze_docker_configuration(doc_content)
            
            # Create comprehensive plan
            deployment_plan = {
                "documentation_found": list(doc_content.keys()),
                "environment_variables": env_vars,
                "required_services": services,
                "deployment_steps": steps,
                "ports": ports,
                "domain_requirements": domain_reqs,
                "docker_configuration": docker_config,
                "tech_stack": tech_stack,
                "recommendations": self._generate_recommendations(
                    services, env_vars, domain_reqs, docker_config
                ),
            }
            
            return {
                "success": True,
                "repo_path": repo_path,
                "deployment_plan": deployment_plan,
                "required_services": services,
                "environment_variables": env_vars,
                "deployment_steps": steps,
                "recommendations": deployment_plan["recommendations"],
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Recon analysis failed: {str(e)}",
            }
    
    def _generate_recommendations(
        self,
        services: list,
        env_vars: dict,
        domain_reqs: dict,
        docker_config: Optional[dict]
    ) -> list:
        """
        Generate deployment recommendations based on analysis.
        
        Args:
            services: List of required services
            env_vars: Environment variables
            domain_reqs: Domain requirements
            docker_config: Docker configuration
            
        Returns:
            List of recommendation strings
        """
        recommendations = []
        
        # Service recommendations
        if services:
            service_types = [s["type"] for s in services]
            recommendations.append(
                f"Provision {len(services)} external service(s): {', '.join(service_types)}"
            )
            
            # Database-specific recommendations
            if "postgresql" in service_types or "mysql" in service_types:
                recommendations.append(
                    "Configure database backups and enable automated snapshots"
                )
            
            if "redis" in service_types:
                recommendations.append(
                    "Consider Redis persistence configuration for cache durability"
                )
        
        # Environment variable recommendations
        if env_vars:
            required_count = sum(1 for v in env_vars.values() if v.get("required"))
            recommendations.append(
                f"Configure {len(env_vars)} environment variable(s) "
                f"({required_count} required)"
            )
        
        # SSL/Domain recommendations
        if domain_reqs.get("needs_ssl"):
            recommendations.append(
                "Configure SSL/TLS certificate (Let's Encrypt recommended)"
            )
        
        if domain_reqs.get("needs_domain"):
            recommendations.append(
                "Set up custom domain and DNS configuration"
            )
        
        # Docker recommendations
        if docker_config:
            if docker_config.get("has_dockerfile"):
                recommendations.append(
                    "Consider using Docker deployment for consistency"
                )
            if docker_config.get("has_compose"):
                recommendations.append(
                    "Docker Compose configuration found - can be used for local testing"
                )
        
        # General recommendations
        recommendations.append(
            "Review security group rules to ensure least privilege access"
        )
        recommendations.append(
            "Set up monitoring and alerting for production deployment"
        )
        
        return recommendations
    
    def quick_scan(self, repo_url: str) -> Dict[str, Any]:
        """
        Quick scan of repository for basic information.
        
        Args:
            repo_url: GitHub repository URL
            
        Returns:
            Basic repository information
        """
        return self.analyze_repository(repo_url, "Quick scan")
