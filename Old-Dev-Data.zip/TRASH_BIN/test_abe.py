"""Unit tests for Abe Agent."""
import pytest
from unittest.mock import Mock, MagicMock, patch
from src.agents.abe import AbeAgent
from src.schemas.deployment import BuildArtifact, InfrastructureSpec, TechStack


@pytest.fixture
def mock_ssh_client():
    """Create mock SSH client."""
    return MagicMock()


@pytest.fixture
def sample_tech_stack():
    """Create sample tech stack."""
    return TechStack(
        language="nodejs",
        framework="express",
        runtime_version="18.x",
        package_manager="npm",
        requires_database=True,
        database_type="postgresql",
    )


@pytest.fixture
def sample_infrastructure():
    """Create sample infrastructure."""
    return InfrastructureSpec(
        vpc_id="vpc-123",
        instance_id="i-123",
        instance_type="t3.micro",
        instance_public_ip="192.168.1.100",
        instance_private_ip="10.0.1.50",
        database_endpoint="db.example.com",
        database_port=5432,
        database_name="myapp",
        database_username="admin",
        database_password="secret123",
    )


@pytest.fixture
def sample_build_artifact():
    """Create sample build artifact."""
    return BuildArtifact(
        artifact_path="/tmp/build/app",
        artifact_type="nodejs_package",
        size_bytes=1024000,
        checksum="abc123",
    )


@pytest.mark.unit
def test_abe_determines_correct_app_port(sample_tech_stack):
    """Test Abe determines correct application port."""
    agent = AbeAgent()
    
    port = agent._determine_app_port(sample_tech_stack)
    assert port == 3000  # Express default


@pytest.mark.unit
def test_abe_builds_database_url(sample_infrastructure, sample_tech_stack):
    """Test Abe builds correct database URL."""
    agent = AbeAgent()
    
    db_url = agent._build_database_url(sample_infrastructure, sample_tech_stack)
    
    assert "postgresql://" in db_url
    assert "admin:secret123" in db_url
    assert "db.example.com:5432" in db_url
    assert "/myapp" in db_url


@pytest.mark.unit
def test_abe_builds_environment_vars(sample_infrastructure, sample_tech_stack):
    """Test Abe builds environment variables."""
    agent = AbeAgent()
    
    env_vars = agent._build_environment_vars(sample_infrastructure, sample_tech_stack)
    
    assert "DATABASE_URL" in env_vars
    assert "DB_HOST" in env_vars
    assert "DB_PORT" in env_vars
    assert "PORT" in env_vars
    assert env_vars["PORT"] == "3000"


@pytest.mark.unit
def test_abe_builds_start_command_nodejs(sample_tech_stack):
    """Test Abe builds correct start command for Node.js."""
    agent = AbeAgent()
    
    command = agent._build_start_command(sample_tech_stack, "/app")
    
    assert "npm start" in command or "node" in command


@pytest.mark.unit
def test_abe_builds_start_command_python_fastapi():
    """Test Abe builds correct start command for FastAPI."""
    agent = AbeAgent()
    
    tech_stack = TechStack(
        language="python",
        framework="fastapi",
        runtime_version="3.11",
        package_manager="pip",
    )
    
    command = agent._build_start_command(tech_stack, "/app")
    
    assert "uvicorn" in command
    assert "main:app" in command


@pytest.mark.unit
def test_abe_builds_start_command_go():
    """Test Abe builds correct start command for Go."""
    agent = AbeAgent()
    
    tech_stack = TechStack(
        language="go",
        runtime_version="1.21",
        package_manager="go mod",
    )
    
    command = agent._build_start_command(tech_stack, "/app")
    
    assert "/app/app" in command


@pytest.mark.unit
@patch('src.agents.abe.ssh_connect')
@patch('src.agents.abe.install_runtime')
@patch('src.agents.abe.copy_artifact')
@patch('src.agents.abe.configure_environment')
@patch('src.agents.abe.start_service')
@patch('src.agents.abe.health_check')
def test_abe_deploy_application_success(
    mock_health,
    mock_start,
    mock_config,
    mock_copy,
    mock_install,
    mock_connect,
    sample_build_artifact,
    sample_infrastructure,
    sample_tech_stack,
):
    """Test successful application deployment."""
    mock_client = MagicMock()
    mock_connect.return_value = mock_client
    
    agent = AbeAgent()
    result = agent.deploy_application(
        sample_build_artifact,
        sample_infrastructure,
        sample_tech_stack,
    )
    
    assert result.success is True
    assert result.deployment_config is not None
    assert result.deployment_config.app_port == 3000
    assert result.deployment_config.service_status == "running"
    
    # Verify all steps were called
    mock_connect.assert_called_once()
    mock_install.assert_called_once()
    mock_copy.assert_called_once()
    mock_config.assert_called_once()
    mock_start.assert_called_once()
    mock_health.assert_called_once()


@pytest.mark.unit
@patch('src.agents.abe.ssh_connect')
def test_abe_deploy_application_connection_failure(
    mock_connect,
    sample_build_artifact,
    sample_infrastructure,
    sample_tech_stack,
):
    """Test deployment handles connection failure."""
    from src.tools.deployment import DeploymentToolError
    
    mock_connect.side_effect = DeploymentToolError("Connection refused")
    
    agent = AbeAgent()
    result = agent.deploy_application(
        sample_build_artifact,
        sample_infrastructure,
        sample_tech_stack,
    )
    
    assert result.success is False
    assert "Connection refused" in result.error_message
