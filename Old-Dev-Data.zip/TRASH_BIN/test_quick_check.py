"""Quick check to verify the system is working."""
import sys

def test_imports():
    """Test that all main modules can be imported."""
    print("Testing imports...")
    
    try:
        # Test schemas
        from src.schemas.deployment import DeploymentState, TechStack
        print("✅ Schemas import OK")
        
        # Test agents
        from src.agents.conductor import ConductorAgent
        from src.agents.compiler import CompilerAgent
        from src.agents.server_monkey import ServerMonkeyAgent
        from src.agents.abe import AbeAgent
        from src.agents.shawn import ShawnAgent
        print("✅ Original agents import OK")
        
        # Test Strands agents
        from src.agents.strands_conductor import StrandsConductorAgent
        from src.agents.strands_compiler import compiler_agent
        from src.agents.strands_server_monkey import server_monkey_agent
        from src.agents.strands_abe import abe_agent
        from src.agents.strands_shawn import shawn_agent
        print("✅ Strands agents import OK")
        
        # Test tools
        from src.tools.repository import analyze_repository
        from src.tools.build import build_nodejs_app
        from src.tools.aws_infrastructure import create_vpc
        from src.tools.deployment import ssh_connect
        from src.tools.security import review_security_groups
        print("✅ Tools import OK")
        
        # Test CLI
        from src.cli import main
        print("✅ CLI import OK")
        
        print("\n🎉 All imports successful!")
        return True
        
    except ImportError as e:
        print(f"\n❌ Import failed: {e}")
        return False


def test_basic_functionality():
    """Test basic functionality."""
    print("\nTesting basic functionality...")
    
    try:
        from src.schemas.deployment import DeploymentState, DeploymentStatus
        from datetime import datetime
        
        # Create a deployment state
        state = DeploymentState(
            deployment_id="test-123",
            repo_url="https://github.com/test/repo",
            user_description="Test deployment",
            status=DeploymentStatus.PENDING,
            started_at=datetime.now(),
        )
        
        # Add a log
        state.add_log("Test log entry")
        
        assert len(state.logs) == 1
        assert "Test log entry" in state.logs[0]
        
        print("✅ Deployment state works")
        
        # Test state transitions
        state.status = DeploymentStatus.ANALYZING
        assert state.status == DeploymentStatus.ANALYZING
        print("✅ State transitions work")
        
        # Test Conductor
        from src.agents.conductor import ConductorAgent
        conductor = ConductorAgent(state_dir="./test_deployments")
        print("✅ Conductor instantiation works")
        
        print("\n🎉 Basic functionality tests passed!")
        return True
        
    except Exception as e:
        print(f"\n❌ Functionality test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    print("=" * 60)
    print("AutoDeploy Agent System - Quick Check")
    print("=" * 60)
    print()
    
    imports_ok = test_imports()
    functionality_ok = test_basic_functionality()
    
    print()
    print("=" * 60)
    if imports_ok and functionality_ok:
        print("✅ System is ready!")
        print()
        print("Next steps:")
        print("1. Run full tests: pytest -v")
        print("2. Or use: ./run_tests.sh")
        print("3. Try example: python example_strands_usage.py")
        sys.exit(0)
    else:
        print("❌ System has issues")
        print()
        print("Try:")
        print("1. Install dependencies: pip install -r requirements.txt")
        print("2. Check Python version: python --version (need 3.10+)")
        sys.exit(1)
