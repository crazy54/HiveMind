"""Unit tests for Conductor Agent."""
import pytest
import tempfile
import shutil
from pathlib import Path
from src.agents.conductor import ConductorAgent, DeploymentResult
from src.schemas.deployment import DeploymentStatus


@pytest.fixture
def temp_state_dir():
    """Create a temporary directory for deployment state."""
    temp_dir = tempfile.mkdtemp()
    yield temp_dir
    shutil.rmtree(temp_dir)


@pytest.mark.unit
def test_conductor_creates_deployment_state(temp_state_dir):
    """Test that Conductor creates deployment state on deploy()."""
    conductor = ConductorAgent(state_dir=temp_state_dir)
    
    result = conductor.deploy(
        repo_url="https://github.com/test/repo",
        description="Test deployment",
    )
    
    assert result is not None
    assert result.deployment_id is not None
    assert len(result.deployment_id) > 0


@pytest.mark.unit
def test_conductor_persists_state(temp_state_dir):
    """Test that Conductor persists state to disk."""
    conductor = ConductorAgent(state_dir=temp_state_dir)
    
    result = conductor.deploy(
        repo_url="https://github.com/test/repo",
        description="Test deployment",
    )
    
    # Check that state file exists
    state_file = Path(temp_state_dir) / f"{result.deployment_id}.json"
    assert state_file.exists()
    
    # Check that we can load the state
    loaded_state = conductor.get_status(result.deployment_id)
    assert loaded_state is not None
    assert loaded_state.deployment_id == result.deployment_id


@pytest.mark.unit
def test_conductor_get_status_returns_none_for_missing_deployment(temp_state_dir):
    """Test that get_status returns None for non-existent deployment."""
    conductor = ConductorAgent(state_dir=temp_state_dir)
    
    state = conductor.get_status("nonexistent-id")
    assert state is None


@pytest.mark.unit
def test_conductor_handles_errors_gracefully(temp_state_dir):
    """Test that Conductor handles errors and updates state to FAILED."""
    conductor = ConductorAgent(state_dir=temp_state_dir)
    
    # This will fail because we haven't implemented agent calls yet
    # But it should handle the error gracefully
    result = conductor.deploy(
        repo_url="https://github.com/test/repo",
        description="Test deployment",
    )
    
    # Even if deployment logic isn't complete, it should return a result
    assert result is not None
    assert result.deployment_id is not None


@pytest.mark.unit
def test_conductor_adds_logs_to_state(temp_state_dir):
    """Test that Conductor adds log entries to deployment state."""
    conductor = ConductorAgent(state_dir=temp_state_dir)
    
    result = conductor.deploy(
        repo_url="https://github.com/test/repo",
        description="Test deployment",
    )
    
    state = conductor.get_status(result.deployment_id)
    assert state is not None
    assert len(state.logs) > 0
    assert any("created" in log.lower() for log in state.logs)


@pytest.mark.unit
def test_conductor_retry_fails_for_nonexistent_deployment(temp_state_dir):
    """Test that retry fails for non-existent deployment."""
    conductor = ConductorAgent(state_dir=temp_state_dir)
    
    result = conductor.retry_deployment("nonexistent-id")
    assert result.success is False
    assert "not found" in result.message.lower()


@pytest.mark.unit
def test_conductor_retry_fails_for_non_failed_deployment(temp_state_dir):
    """Test that retry fails for deployments that aren't in FAILED status."""
    conductor = ConductorAgent(state_dir=temp_state_dir)
    
    # Create a deployment
    deploy_result = conductor.deploy(
        repo_url="https://github.com/test/repo",
        description="Test deployment",
    )
    
    # Try to retry (it's not in FAILED status)
    retry_result = conductor.retry_deployment(deploy_result.deployment_id)
    
    # Should fail because deployment isn't in FAILED status
    # (it's either COMPLETED or in progress)
    if retry_result.state and retry_result.state.status != DeploymentStatus.FAILED:
        assert retry_result.success is False or retry_result.message == "Retry initiated"
