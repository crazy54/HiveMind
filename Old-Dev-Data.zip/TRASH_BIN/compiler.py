"""Compiler Agent - Builds and compiles source code."""
from typing import Optional
from src.schemas.deployment import BuildArtifact, TechStack
from src.tools.repository import analyze_repository, RepositoryAnalysisError
from src.tools.build import (
    build_nodejs_app,
    build_python_app,
    build_go_app,
    BuildError,
)


class BuildResult:
    """Result of build operation."""
    
    def __init__(
        self,
        success: bool,
        tech_stack: Optional[TechStack] = None,
        build_artifact: Optional[BuildArtifact] = None,
        error_message: Optional[str] = None,
    ):
        self.success = success
        self.tech_stack = tech_stack
        self.build_artifact = build_artifact
        self.error_message = error_message


class CompilerAgent:
    """
    Compiler Agent analyzes and builds applications.
    
    Responsibilities:
    - Analyzes repository to detect tech stack
    - Selects appropriate build tools
    - Executes build process
    - Validates build success
    - Creates build artifacts
    - Reports build errors with actionable feedback
    """
    
    def __init__(self, repo_clone_dir: str = "./repos"):
        """
        Initialize the Compiler Agent.
        
        Args:
            repo_clone_dir: Directory for cloning repositories
        """
        self.repo_clone_dir = repo_clone_dir
    
    def analyze_and_build(
        self,
        repo_url: str,
        deployment_id: str,
    ) -> BuildResult:
        """
        Clone repository, detect tech stack, and build application.
        
        Args:
            repo_url: Repository URL to clone
            deployment_id: Unique deployment identifier
            
        Returns:
            BuildResult with tech_stack and build_artifact
        """
        local_path = f"{self.repo_clone_dir}/{deployment_id}"
        
        try:
            # Analyze repository
            tech_stack = self.detect_tech_stack(repo_url, local_path)
            
            # Build application
            build_artifact = self.build_application(local_path, tech_stack)
            
            return BuildResult(
                success=True,
                tech_stack=tech_stack,
                build_artifact=build_artifact,
            )
            
        except RepositoryAnalysisError as e:
            return BuildResult(
                success=False,
                error_message=f"Repository analysis failed: {str(e)}. "
                             f"Please ensure the repository URL is correct and accessible.",
            )
        except BuildError as e:
            return BuildResult(
                success=False,
                error_message=f"Build failed: {str(e)}. "
                             f"Please check your dependencies and build configuration.",
            )
        except Exception as e:
            return BuildResult(
                success=False,
                error_message=f"Unexpected error: {str(e)}",
            )
    
    def detect_tech_stack(self, repo_url: str, local_path: str) -> TechStack:
        """
        Analyze repository to detect language, framework, dependencies.
        
        Args:
            repo_url: Repository URL
            local_path: Local path for cloning
            
        Returns:
            TechStack with detected information
            
        Raises:
            RepositoryAnalysisError: If analysis fails
        """
        return analyze_repository(repo_url, local_path)
    
    def build_application(
        self,
        repo_path: str,
        tech_stack: TechStack,
    ) -> BuildArtifact:
        """
        Execute build process based on detected tech stack.
        
        Args:
            repo_path: Path to repository
            tech_stack: Detected technology stack
            
        Returns:
            BuildArtifact with build information
            
        Raises:
            BuildError: If build fails
        """
        if tech_stack.language == "nodejs":
            return build_nodejs_app(repo_path, tech_stack)
        elif tech_stack.language == "python":
            return build_python_app(repo_path, tech_stack)
        elif tech_stack.language == "go":
            return build_go_app(repo_path, tech_stack)
        else:
            raise BuildError(f"Unsupported language: {tech_stack.language}")
