"""Abe Agent using Strands SDK."""
from strands import Agent
from src.tools.deployment_tools import (
    install_runtime,
    configure_application_environment,
    start_application_service,
    verify_application_health,
)


# Create Abe Agent with deployment tools
abe_agent = Agent(
    name="Abe",
    system_prompt="""You are Abe, the Application Deployment Agent responsible for deploying and configuring applications on infrastructure.

Your responsibilities:
1. Install runtime dependencies (Node.js, Python, Go)
2. Copy application artifacts to the server
3. Configure environment variables (including database connections)
4. Start the application service using systemd
5. Verify the application is healthy and responding

When given build artifact, infrastructure details, and tech stack:
1. Use install_runtime to install the appropriate runtime on the server
2. Use configure_application_environment to set up environment variables (DATABASE_URL, PORT, etc.)
3. Use start_application_service to start the application as a systemd service
4. Use verify_application_health to confirm the application is running

Environment variable guidelines:
- Always set DATABASE_URL if database is available
- Set PORT based on framework (Express: 3000, FastAPI: 8000, Flask: 5000, Django: 8000, Gin: 8080)
- Set NODE_ENV=production for Node.js apps
- Include DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD for database apps

Start command guidelines:
- Node.js: "npm start" or "node server.js"
- Python/FastAPI: "uvicorn main:app --host 0.0.0.0 --port 8000"
- Python/Flask: "python app.py"
- Python/Django: "python manage.py runserver 0.0.0.0:8000"
- Go: "./app"

Always provide complete deployment details including:
- Runtime installation status
- Environment variables configured
- Service name and status
- Application URL and health check results""",
    tools=[
        install_runtime,
        configure_application_environment,
        start_application_service,
        verify_application_health,
    ],
)


def run_abe_agent(
    build_artifact: dict,
    infrastructure: dict,
    tech_stack: dict,
    ssh_key_path: str,
) -> dict:
    """
    Run Abe agent to deploy application.
    
    Args:
        build_artifact: Dictionary with artifact information
        infrastructure: Dictionary with infrastructure details
        tech_stack: Dictionary with tech stack information
        ssh_key_path: Path to SSH private key
        
    Returns:
        Dictionary with deployment configuration
    """
    message = f"""Please deploy the application to the provisioned infrastructure:

Tech Stack:
- Language: {tech_stack.get('language')}
- Framework: {tech_stack.get('framework')}
- Runtime Version: {tech_stack.get('runtime_version')}
- Requires Database: {tech_stack.get('requires_database')}

Infrastructure:
- Instance IP: {infrastructure.get('instance_public_ip')}
- Database Endpoint: {infrastructure.get('database_endpoint')}
- Database Port: {infrastructure.get('database_port')}
- Database Name: {infrastructure.get('database_name')}
- Database Username: {infrastructure.get('database_username')}
- Database Password: {infrastructure.get('database_password')}

Build Artifact:
- Path: {build_artifact.get('artifact_path')}
- Type: {build_artifact.get('artifact_type')}

SSH Key: {ssh_key_path}

Steps to follow:
1. Install runtime ({tech_stack.get('language')} {tech_stack.get('runtime_version')})
2. Configure environment variables (including database connection if available)
3. Start the application service
4. Verify application health

Provide complete deployment details."""

    result = abe_agent(message)
    
    # Extract response text
    response_text = ""
    if hasattr(result, "content"):
        response_text = result.content
    elif hasattr(result, "message"):
        response_text = str(result.message)
    else:
        response_text = str(result)
    
    return {
        "success": True,
        "response": response_text,
        "tool_calls": [
            {
                "tool": call.get("name"),
                "result": call.get("result")
            }
            for call in result.tool_calls
        ] if hasattr(result, "tool_calls") and result.tool_calls else []
    }
