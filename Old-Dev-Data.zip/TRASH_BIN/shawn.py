"""Shawn Agent - Security hardening."""
from typing import Optional
from src.schemas.deployment import InfrastructureSpec, DeploymentConfig, SecurityConfig
from src.tools.security import (
    review_security_groups,
    harden_os,
    configure_firewall,
    run_vulnerability_scan,
    SecurityError,
)
from src.tools.deployment import ssh_connect


class SecurityResult:
    """Result of security hardening."""
    
    def __init__(
        self,
        success: bool,
        security_config: Optional[SecurityConfig] = None,
        error_message: Optional[str] = None,
    ):
        self.success = success
        self.security_config = security_config
        self.error_message = error_message


class ShawnAgent:
    """Shawn Agent hardens security."""
    
    def __init__(self, ssh_key_path: str = "~/.ssh/id_rsa", region: str = "us-east-1"):
        self.ssh_key_path = ssh_key_path
        self.region = region
    
    def harden_security(
        self,
        infrastructure: InfrastructureSpec,
        deployment_config: DeploymentConfig,
    ) -> SecurityResult:
        """Harden security across infrastructure and application."""
        try:
            # Review security groups
            sg_analysis = review_security_groups(
                infrastructure.security_group_ids,
                self.region
            )
            
            # Connect and harden OS
            client = ssh_connect(
                infrastructure.instance_public_ip,
                "ec2-user",
                key_file=self.ssh_key_path
            )
            
            os_hardening = harden_os(client, infrastructure.instance_public_ip)
            
            # Configure firewall
            allowed_ports = [22, 80, 443, deployment_config.app_port]
            configure_firewall(client, allowed_ports)
            
            client.close()
            
            # Run vulnerability scan
            scan_results = run_vulnerability_scan(infrastructure.instance_id, self.region)
            
            # Create security config
            security_config = SecurityConfig(
                ssl_enabled=False,  # Would be configured with load balancer
                security_group_rules=sg_analysis.get("security_groups", []),
                firewall_enabled=os_hardening.get("firewall_enabled", False),
                os_hardening_applied=os_hardening.get("updates_installed", False),
                vulnerability_scan_results=scan_results,
                compliance_checks=["security_groups_reviewed", "os_hardened", "firewall_configured"],
            )
            
            return SecurityResult(success=True, security_config=security_config)
            
        except (SecurityError, Exception) as e:
            return SecurityResult(success=False, error_message=str(e))
