"""Tests for HiveMind Recon Agent."""
import pytest
from unittest.mock import Mock, patch, MagicMock
from src.agents.recon import ReconAgent
from src.tools.documentation import (
    read_documentation_files,
    extract_environment_variables,
    extract_service_requirements,
    extract_deployment_steps,
    extract_port_requirements,
    extract_domain_requirements,
    analyze_docker_configuration,
)


@pytest.fixture
def recon_agent():
    """Create Recon agent instance."""
    return ReconAgent()


@pytest.fixture
def sample_readme():
    """Sample README content."""
    return """
    # My Application
    
    This is a Node.js application using Express and PostgreSQL.
    
    ## Requirements
    
    - Node.js 18+
    - PostgreSQL 14+
    - Redis for caching
    
    ## Environment Variables
    
    Required:
    - DATABASE_URL - PostgreSQL connection string
    - REDIS_URL - Redis connection string
    - SECRET_KEY - Application secret key
    
    ## Deployment
    
    1. Run database migrations: `npm run migrate`
    2. Build the application: `npm run build`
    3. Start the server: `npm start`
    
    The application runs on port 3000.
    
    ## SSL
    
    This application requires HTTPS in production.
    """


@pytest.fixture
def sample_dockerfile():
    """Sample Dockerfile content."""
    return """
    FROM node:18-alpine
    
    WORKDIR /app
    
    COPY package*.json ./
    RUN npm install
    
    COPY . .
    
    EXPOSE 3000
    
    CMD ["npm", "start"]
    """


@pytest.fixture
def sample_docker_compose():
    """Sample docker-compose.yml content."""
    return """
    version: '3.8'
    services:
      app:
        build: .
        ports:
          - "3000:3000"
        environment:
          - DATABASE_URL=postgresql://user:pass@db:5432/myapp
          - REDIS_URL=redis://redis:6379
      db:
        image: postgres:14
        environment:
          - POSTGRES_DB=myapp
      redis:
        image: redis:7-alpine
    """


class TestDocumentationReading:
    """Test documentation file reading."""
    
    def test_read_documentation_files(self, tmp_path):
        """Test reading documentation files from repository."""
        # Create test files
        (tmp_path / "README.md").write_text("# Test Project")
        (tmp_path / "DEPLOY.md").write_text("Deployment instructions")
        (tmp_path / ".env.example").write_text("DATABASE_URL=")
        
        result = read_documentation_files(str(tmp_path))
        
        assert "README.md" in result
        assert "DEPLOY.md" in result
        assert ".env.example" in result
        assert result["README.md"] == "# Test Project"
    
    def test_read_documentation_no_files(self, tmp_path):
        """Test reading from directory with no documentation."""
        result = read_documentation_files(str(tmp_path))
        assert result == {}
    
    def test_read_documentation_nested_docs(self, tmp_path):
        """Test reading nested documentation."""
        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "deployment.md").write_text("Deploy instructions")
        
        result = read_documentation_files(str(tmp_path))
        assert "docs/deployment.md" in result


class TestEnvironmentVariableExtraction:
    """Test environment variable extraction."""
    
    def test_extract_env_vars_from_readme(self, sample_readme):
        """Test extracting environment variables from README."""
        doc_content = {"README.md": sample_readme}
        env_vars = extract_environment_variables(doc_content)
        
        assert "DATABASE_URL" in env_vars
        assert "REDIS_URL" in env_vars
        assert "SECRET_KEY" in env_vars
        assert env_vars["DATABASE_URL"]["found_in"] == "README.md"
    
    def test_extract_env_vars_from_env_example(self):
        """Test extracting from .env.example."""
        content = """
        DATABASE_URL="postgresql://localhost/myapp"
        REDIS_URL="redis://localhost:6379"
        API_KEY="your-api-key"
        """
        doc_content = {".env.example": content}
        env_vars = extract_environment_variables(doc_content)
        
        assert "DATABASE_URL" in env_vars
        assert "REDIS_URL" in env_vars
        assert "API_KEY" in env_vars
    
    def test_extract_env_vars_from_dockerfile(self, sample_dockerfile):
        """Test extracting from Dockerfile."""
        content = sample_dockerfile + "\nENV NODE_ENV=production\nENV PORT=3000"
        doc_content = {"Dockerfile": content}
        env_vars = extract_environment_variables(doc_content)
        
        assert "NODE_ENV" in env_vars
        assert "PORT" in env_vars


class TestServiceRequirements:
    """Test service requirement extraction."""
    
    def test_extract_postgresql_requirement(self, sample_readme):
        """Test detecting PostgreSQL requirement."""
        doc_content = {"README.md": sample_readme}
        services = extract_service_requirements(doc_content)
        
        postgres_services = [s for s in services if s["type"] == "postgresql"]
        assert len(postgres_services) > 0
        assert postgres_services[0]["version"] == "14"
    
    def test_extract_redis_requirement(self, sample_readme):
        """Test detecting Redis requirement."""
        doc_content = {"README.md": sample_readme}
        services = extract_service_requirements(doc_content)
        
        redis_services = [s for s in services if s["type"] == "redis"]
        assert len(redis_services) > 0
    
    def test_extract_multiple_services(self):
        """Test detecting multiple services."""
        content = """
        This app uses:
        - PostgreSQL 13 for data
        - Redis for caching
        - MongoDB for logs
        - Elasticsearch for search
        """
        doc_content = {"README.md": content}
        services = extract_service_requirements(doc_content)
        
        service_types = [s["type"] for s in services]
        assert "postgresql" in service_types
        assert "redis" in service_types
        assert "mongodb" in service_types
        assert "elasticsearch" in service_types
    
    def test_no_services_detected(self):
        """Test when no services are mentioned."""
        doc_content = {"README.md": "Simple static site"}
        services = extract_service_requirements(doc_content)
        assert len(services) == 0


class TestDeploymentSteps:
    """Test deployment step extraction."""
    
    def test_extract_migration_steps(self, sample_readme):
        """Test extracting migration steps."""
        doc_content = {"README.md": sample_readme}
        steps = extract_deployment_steps(doc_content)
        
        assert len(steps["pre_deploy"]) > 0
        assert any("migrate" in step.lower() for step in steps["pre_deploy"])
    
    def test_extract_build_steps(self, sample_readme):
        """Test extracting build steps."""
        doc_content = {"README.md": sample_readme}
        steps = extract_deployment_steps(doc_content)
        
        assert len(steps["build"]) > 0
        assert any("build" in step.lower() for step in steps["build"])
    
    def test_extract_post_deploy_steps(self):
        """Test extracting post-deployment steps."""
        content = """
        After deployment:
        1. Run health check: curl http://localhost/health
        2. Warm up cache
        3. Reindex search
        """
        doc_content = {"DEPLOY.md": content}
        steps = extract_deployment_steps(doc_content)
        
        assert len(steps["post_deploy"]) > 0


class TestPortExtraction:
    """Test port number extraction."""
    
    def test_extract_port_from_readme(self, sample_readme):
        """Test extracting port from README."""
        doc_content = {"README.md": sample_readme}
        ports = extract_port_requirements(doc_content)
        
        assert 3000 in ports
    
    def test_extract_multiple_ports(self):
        """Test extracting multiple ports."""
        content = """
        Services:
        - API: port 3000
        - Admin: port 3001
        - Metrics: localhost:9090
        """
        doc_content = {"README.md": content}
        ports = extract_port_requirements(doc_content)
        
        assert 3000 in ports
        assert 3001 in ports
        assert 9090 in ports
    
    def test_extract_port_from_dockerfile(self, sample_dockerfile):
        """Test extracting port from Dockerfile."""
        doc_content = {"Dockerfile": sample_dockerfile}
        ports = extract_port_requirements(doc_content)
        
        assert 3000 in ports


class TestDomainRequirements:
    """Test domain and SSL requirement extraction."""
    
    def test_detect_ssl_requirement(self, sample_readme):
        """Test detecting SSL requirement."""
        doc_content = {"README.md": sample_readme}
        domain_reqs = extract_domain_requirements(doc_content)
        
        assert domain_reqs["needs_ssl"] is True
    
    def test_detect_domain_requirement(self):
        """Test detecting domain requirement."""
        content = "Configure your custom domain in the settings."
        doc_content = {"README.md": content}
        domain_reqs = extract_domain_requirements(doc_content)
        
        assert domain_reqs["needs_domain"] is True
    
    def test_no_ssl_or_domain(self):
        """Test when no SSL or domain mentioned."""
        content = "Simple application"
        doc_content = {"README.md": content}
        domain_reqs = extract_domain_requirements(doc_content)
        
        assert domain_reqs["needs_ssl"] is False
        assert domain_reqs["needs_domain"] is False


class TestDockerAnalysis:
    """Test Docker configuration analysis."""
    
    def test_analyze_dockerfile(self, sample_dockerfile):
        """Test analyzing Dockerfile."""
        doc_content = {"Dockerfile": sample_dockerfile}
        docker_config = analyze_docker_configuration(doc_content)
        
        assert docker_config is not None
        assert docker_config["has_dockerfile"] is True
        assert docker_config["base_image"] == "node:18-alpine"
        assert 3000 in docker_config["exposed_ports"]
    
    def test_analyze_docker_compose(self, sample_docker_compose):
        """Test analyzing docker-compose.yml."""
        doc_content = {"docker-compose.yml": sample_docker_compose}
        docker_config = analyze_docker_configuration(doc_content)
        
        assert docker_config is not None
        assert docker_config["has_compose"] is True
    
    def test_no_docker_config(self):
        """Test when no Docker configuration present."""
        doc_content = {"README.md": "No Docker here"}
        docker_config = analyze_docker_configuration(doc_content)
        
        assert docker_config is None


class TestReconAgent:
    """Test Recon Agent."""
    
    @patch('src.agents.recon.core_clone_repository')
    @patch('src.agents.recon.read_documentation_files')
    def test_analyze_repository_success(
        self,
        mock_read_docs,
        mock_clone,
        recon_agent,
        sample_readme
    ):
        """Test successful repository analysis."""
        # Mock clone
        mock_clone.return_value = {
            "success": True,
            "repo_path": "/tmp/test-repo"
        }
        
        # Mock documentation reading
        mock_read_docs.return_value = {
            "README.md": sample_readme
        }
        
        result = recon_agent.analyze_repository(
            "https://github.com/test/repo",
            "Test deployment"
        )
        
        assert result["success"] is True
        assert "deployment_plan" in result
        assert "required_services" in result
        assert len(result["required_services"]) > 0
    
    @patch('src.agents.recon.core_clone_repository')
    def test_analyze_repository_clone_failure(self, mock_clone, recon_agent):
        """Test handling clone failure."""
        mock_clone.return_value = {
            "success": False,
            "error": "Repository not found"
        }
        
        result = recon_agent.analyze_repository(
            "https://github.com/test/invalid",
            "Test"
        )
        
        assert result["success"] is False
        assert "error" in result
    
    @patch('src.agents.recon.core_clone_repository')
    @patch('src.agents.recon.read_documentation_files')
    def test_analyze_repository_no_docs(
        self,
        mock_read_docs,
        mock_clone,
        recon_agent
    ):
        """Test handling no documentation found."""
        mock_clone.return_value = {
            "success": True,
            "repo_path": "/tmp/test-repo"
        }
        mock_read_docs.return_value = {}
        
        result = recon_agent.analyze_repository(
            "https://github.com/test/repo",
            "Test"
        )
        
        assert result["success"] is False
        assert "No documentation" in result["error"]
    
    def test_generate_recommendations(self, recon_agent):
        """Test recommendation generation."""
        services = [
            {"type": "postgresql", "version": "14"},
            {"type": "redis"}
        ]
        env_vars = {
            "DATABASE_URL": {"required": True},
            "API_KEY": {"required": False}
        }
        domain_reqs = {
            "needs_ssl": True,
            "needs_domain": True
        }
        docker_config = {"has_dockerfile": True}
        
        recommendations = recon_agent._generate_recommendations(
            services, env_vars, domain_reqs, docker_config
        )
        
        assert len(recommendations) > 0
        assert any("postgresql" in r.lower() for r in recommendations)
        assert any("ssl" in r.lower() for r in recommendations)
        assert any("docker" in r.lower() for r in recommendations)


class TestIntegration:
    """Integration tests for Recon."""
    
    @patch('src.agents.recon.core_clone_repository')
    def test_full_analysis_workflow(
        self,
        mock_clone,
        recon_agent,
        tmp_path,
        sample_readme,
        sample_dockerfile
    ):
        """Test complete analysis workflow."""
        # Create test repository
        (tmp_path / "README.md").write_text(sample_readme)
        (tmp_path / "Dockerfile").write_text(sample_dockerfile)
        
        mock_clone.return_value = {
            "success": True,
            "repo_path": str(tmp_path)
        }
        
        result = recon_agent.analyze_repository(
            "https://github.com/test/repo",
            "Deploy Node.js app with PostgreSQL"
        )
        
        assert result["success"] is True
        
        # Check deployment plan
        plan = result["deployment_plan"]
        assert "README.md" in plan["documentation_found"]
        assert "Dockerfile" in plan["documentation_found"]
        
        # Check services
        services = result["required_services"]
        service_types = [s["type"] for s in services]
        assert "postgresql" in service_types
        assert "redis" in service_types
        
        # Check environment variables
        env_vars = result["environment_variables"]
        assert "DATABASE_URL" in env_vars
        
        # Check recommendations
        recommendations = result["recommendations"]
        assert len(recommendations) > 0
