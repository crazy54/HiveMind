"""Server-Monkey Agent - Provisions AWS infrastructure."""
from typing import Optional
from src.schemas.deployment import TechStack, InfrastructureSpec
from src.tools.aws_infrastructure import (
    create_vpc,
    create_security_group,
    create_ec2_instance,
    create_rds_instance,
    InfrastructureError,
)


class ProvisioningResult:
    """Result of infrastructure provisioning."""
    
    def __init__(
        self,
        success: bool,
        infrastructure: Optional[InfrastructureSpec] = None,
        error_message: Optional[str] = None,
    ):
        self.success = success
        self.infrastructure = infrastructure
        self.error_message = error_message


class ServerMonkeyAgent:
    """
    Server-Monkey Agent provisions AWS infrastructure.
    
    Responsibilities:
    - Provisions AWS VPC and networking
    - Creates EC2 compute instances
    - Provisions RDS databases when needed
    - Configures security groups
    - Creates load balancers for web apps
    - Returns infrastructure specifications
    """
    
    def __init__(self, region: str = "us-east-1"):
        """
        Initialize the Server-Monkey Agent.
        
        Args:
            region: AWS region for resource provisioning
        """
        self.region = region
    
    def provision_infrastructure(
        self,
        tech_stack: TechStack,
        deployment_id: str,
    ) -> ProvisioningResult:
        """
        Provision AWS infrastructure based on application requirements.
        
        Args:
            tech_stack: Detected technology stack
            deployment_id: Unique deployment identifier for resource tagging
            
        Returns:
            ProvisioningResult with InfrastructureSpec
        """
        try:
            # Determine instance type based on tech stack
            instance_type = self._determine_instance_type(tech_stack)
            
            # Create VPC
            vpc_config = create_vpc(deployment_id, region=self.region)
            
            # Create security group
            app_port = self._determine_app_port(tech_stack)
            security_group_id = create_security_group(
                vpc_id=vpc_config["vpc_id"],
                deployment_id=deployment_id,
                app_port=app_port,
                region=self.region,
            )
            
            # Create EC2 instance
            instance_config = create_ec2_instance(
                subnet_id=vpc_config["public_subnet_id"],
                security_group_id=security_group_id,
                deployment_id=deployment_id,
                instance_type=instance_type,
                region=self.region,
            )
            
            # Create RDS database if needed
            db_config = None
            if tech_stack.requires_database:
                db_config = create_rds_instance(
                    subnet_ids=[
                        vpc_config["public_subnet_id"],
                        vpc_config["private_subnet_id"],
                    ],
                    security_group_id=security_group_id,
                    deployment_id=deployment_id,
                    db_type=tech_stack.database_type or "postgresql",
                    region=self.region,
                )
            
            # Build infrastructure spec
            infrastructure = InfrastructureSpec(
                vpc_id=vpc_config["vpc_id"],
                subnet_ids=[
                    vpc_config["public_subnet_id"],
                    vpc_config["private_subnet_id"],
                ],
                security_group_ids=[security_group_id],
                instance_id=instance_config["instance_id"],
                instance_type=instance_config["instance_type"],
                instance_public_ip=instance_config["public_ip"],
                instance_private_ip=instance_config["private_ip"],
                database_endpoint=db_config["endpoint"] if db_config else None,
                database_port=db_config["port"] if db_config else None,
                database_name=db_config["database_name"] if db_config else None,
                database_username=db_config["username"] if db_config else None,
                database_password=db_config["password"] if db_config else None,
            )
            
            return ProvisioningResult(
                success=True,
                infrastructure=infrastructure,
            )
            
        except InfrastructureError as e:
            return ProvisioningResult(
                success=False,
                error_message=f"Infrastructure provisioning failed: {str(e)}. "
                             f"Please check AWS service limits and permissions.",
            )
        except Exception as e:
            return ProvisioningResult(
                success=False,
                error_message=f"Unexpected error during provisioning: {str(e)}",
            )
    
    def _determine_instance_type(self, tech_stack: TechStack) -> str:
        """
        Determine appropriate EC2 instance type based on tech stack.
        
        Args:
            tech_stack: Detected technology stack
            
        Returns:
            EC2 instance type string
        """
        # Default to t3.micro for most applications
        instance_type = "t3.micro"
        
        # Upgrade for specific frameworks or requirements
        if tech_stack.framework in ["django", "spring", "rails"]:
            # Heavier frameworks need more resources
            instance_type = "t3.small"
        
        if tech_stack.requires_database:
            # Applications with databases might need more memory
            instance_type = "t3.small"
        
        # Go applications are typically more efficient
        if tech_stack.language == "go":
            instance_type = "t3.micro"
        
        return instance_type
    
    def _determine_app_port(self, tech_stack: TechStack) -> int:
        """
        Determine application port based on tech stack.
        
        Args:
            tech_stack: Detected technology stack
            
        Returns:
            Port number
        """
        # Default ports by framework
        framework_ports = {
            "express": 3000,
            "nextjs": 3000,
            "react": 3000,
            "vue": 8080,
            "fastapi": 8000,
            "flask": 5000,
            "django": 8000,
            "gin": 8080,
            "fiber": 3000,
        }
        
        if tech_stack.framework and tech_stack.framework in framework_ports:
            return framework_ports[tech_stack.framework]
        
        # Default by language
        language_ports = {
            "nodejs": 3000,
            "python": 8000,
            "go": 8080,
            "java": 8080,
        }
        
        return language_ports.get(tech_stack.language, 3000)
