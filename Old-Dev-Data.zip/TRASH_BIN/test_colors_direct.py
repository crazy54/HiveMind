#!/usr/bin/env python3
"""Direct color test - writes to stdout without capture."""
import sys
sys.path.insert(0, '.')

from src.utils.colors import info, success, failure, warning, tool, action, COLORS_ENABLED

print(f"Colors enabled: {COLORS_ENABLED}")
print()

# Write directly to stdout
sys.stdout.write(info('🔍 This should be CYAN') + '\n')
sys.stdout.write(success('✅ This should be GREEN') + '\n')
sys.stdout.write(failure('❌ This should be RED') + '\n')
sys.stdout.write(warning('⚠️  This should be YELLOW') + '\n')
sys.stdout.write(tool('🔧 This should be LIGHT BLUE') + '\n')
sys.stdout.write(action('🚀 This should be NEON GREEN') + '\n')
sys.stdout.flush()
