"""Unit tests for Server-Monkey Agent."""
import pytest
from moto import mock_aws
from src.agents.server_monkey import ServerMonkeyAgent
from src.schemas.deployment import TechStack


@pytest.mark.unit
@mock_aws
@mock_aws
def test_server_monkey_provisions_infrastructure_without_database():
    """Test infrastructure provisioning without database."""
    agent = ServerMonkeyAgent(region="us-east-1")
    
    tech_stack = TechStack(
        language="nodejs",
        framework="express",
        runtime_version="18.x",
        package_manager="npm",
        requires_database=False,
    )
    
    result = agent.provision_infrastructure(
        tech_stack=tech_stack,
        deployment_id="test-123",
    )
    
    assert result.success is True
    assert result.infrastructure is not None
    assert result.infrastructure.vpc_id is not None
    assert result.infrastructure.instance_id is not None
    assert result.infrastructure.instance_public_ip is not None
    assert result.infrastructure.database_endpoint is None


@pytest.mark.unit
@mock_aws
@mock_aws
def test_server_monkey_provisions_infrastructure_with_database():
    """Test infrastructure provisioning with database."""
    agent = ServerMonkeyAgent(region="us-east-1")
    
    tech_stack = TechStack(
        language="python",
        framework="fastapi",
        runtime_version="3.11",
        package_manager="pip",
        requires_database=True,
        database_type="postgresql",
    )
    
    result = agent.provision_infrastructure(
        tech_stack=tech_stack,
        deployment_id="test-456",
    )
    
    assert result.success is True
    assert result.infrastructure is not None
    assert result.infrastructure.database_endpoint is not None
    assert result.infrastructure.database_port is not None
    assert result.infrastructure.database_username is not None
    assert result.infrastructure.database_password is not None


@pytest.mark.unit
def test_determine_instance_type_for_lightweight_app():
    """Test instance type determination for lightweight applications."""
    agent = ServerMonkeyAgent()
    
    tech_stack = TechStack(
        language="nodejs",
        framework="express",
        runtime_version="18.x",
        package_manager="npm",
        requires_database=False,
    )
    
    instance_type = agent._determine_instance_type(tech_stack)
    assert instance_type == "t3.micro"


@pytest.mark.unit
def test_determine_instance_type_for_heavy_framework():
    """Test instance type determination for heavy frameworks."""
    agent = ServerMonkeyAgent()
    
    tech_stack = TechStack(
        language="python",
        framework="django",
        runtime_version="3.11",
        package_manager="pip",
        requires_database=True,
    )
    
    instance_type = agent._determine_instance_type(tech_stack)
    assert instance_type == "t3.small"


@pytest.mark.unit
def test_determine_instance_type_with_database():
    """Test instance type determination for apps with database."""
    agent = ServerMonkeyAgent()
    
    tech_stack = TechStack(
        language="nodejs",
        framework="express",
        runtime_version="18.x",
        package_manager="npm",
        requires_database=True,
        database_type="postgresql",
    )
    
    instance_type = agent._determine_instance_type(tech_stack)
    assert instance_type == "t3.small"


@pytest.mark.unit
def test_determine_app_port_for_express():
    """Test app port determination for Express."""
    agent = ServerMonkeyAgent()
    
    tech_stack = TechStack(
        language="nodejs",
        framework="express",
        runtime_version="18.x",
        package_manager="npm",
    )
    
    port = agent._determine_app_port(tech_stack)
    assert port == 3000


@pytest.mark.unit
def test_determine_app_port_for_fastapi():
    """Test app port determination for FastAPI."""
    agent = ServerMonkeyAgent()
    
    tech_stack = TechStack(
        language="python",
        framework="fastapi",
        runtime_version="3.11",
        package_manager="pip",
    )
    
    port = agent._determine_app_port(tech_stack)
    assert port == 8000


@pytest.mark.unit
def test_determine_app_port_for_go():
    """Test app port determination for Go applications."""
    agent = ServerMonkeyAgent()
    
    tech_stack = TechStack(
        language="go",
        framework="gin",
        runtime_version="1.21",
        package_manager="go mod",
    )
    
    port = agent._determine_app_port(tech_stack)
    assert port == 8080


@pytest.mark.unit
def test_determine_app_port_default():
    """Test app port determination defaults to 3000."""
    agent = ServerMonkeyAgent()
    
    tech_stack = TechStack(
        language="unknown",
        runtime_version="1.0",
        package_manager="unknown",
    )
    
    port = agent._determine_app_port(tech_stack)
    assert port == 3000


@pytest.mark.unit
@mock_aws
@mock_aws
def test_infrastructure_spec_generation():
    """Test that infrastructure spec contains all required fields."""
    agent = ServerMonkeyAgent(region="us-east-1")
    
    tech_stack = TechStack(
        language="python",
        framework="flask",
        runtime_version="3.11",
        package_manager="pip",
        requires_database=True,
        database_type="mysql",
    )
    
    result = agent.provision_infrastructure(
        tech_stack=tech_stack,
        deployment_id="test-789",
    )
    
    assert result.success is True
    infra = result.infrastructure
    
    # Check all required fields are present
    assert infra.vpc_id is not None
    assert len(infra.subnet_ids) == 2
    assert len(infra.security_group_ids) == 1
    assert infra.instance_id is not None
    assert infra.instance_type is not None
    assert infra.instance_public_ip is not None
    assert infra.instance_private_ip is not None
    assert infra.database_endpoint is not None
    assert infra.database_port is not None
    assert infra.database_name is not None
    assert infra.database_username is not None
    assert infra.database_password is not None
