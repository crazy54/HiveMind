"""Example usage of AutoDeploy with Strands SDK."""
from src.agents.strands_conductor import StrandsConductorAgent


def main():
    """Example deployment using Strands agents."""
    
    # Create conductor agent
    conductor = StrandsConductorAgent(
        state_dir="./deployments",
        region="us-east-1"
    )
    
    # Example 1: Deploy a Node.js application
    print("=" * 60)
    print("Example 1: Deploying Node.js Express Application")
    print("=" * 60)
    
    result = conductor.deploy(
        repo_url="https://github.com/user/express-app",
        description="Deploy my Express.js REST API with PostgreSQL database"
    )
    
    print(f"\nDeployment ID: {result.deployment_id}")
    print(f"Success: {result.success}")
    print(f"Message: {result.message}")
    
    if result.state:
        print(f"\nStatus: {result.state.status}")
        print(f"\nLogs:")
        for log in result.state.logs:
            print(f"  {log}")
        
        if result.state.tech_stack:
            print(f"\nDetected Tech Stack:")
            print(f"  Language: {result.state.tech_stack.language}")
            print(f"  Framework: {result.state.tech_stack.framework}")
            print(f"  Runtime: {result.state.tech_stack.runtime_version}")
        
        if result.state.infrastructure:
            print(f"\nProvisioned Infrastructure:")
            print(f"  VPC ID: {result.state.infrastructure.vpc_id}")
            print(f"  Instance ID: {result.state.infrastructure.instance_id}")
            print(f"  Public IP: {result.state.infrastructure.instance_public_ip}")
            if result.state.infrastructure.database_endpoint:
                print(f"  Database: {result.state.infrastructure.database_endpoint}")
    
    # Example 2: Check deployment status
    print("\n" + "=" * 60)
    print("Example 2: Checking Deployment Status")
    print("=" * 60)
    
    status = conductor.get_status(result.deployment_id)
    if status:
        print(f"\nDeployment {result.deployment_id}")
        print(f"Status: {status.status}")
        print(f"Started: {status.started_at}")
        print(f"Completed: {status.completed_at}")
        print(f"\nTotal logs: {len(status.logs)}")


if __name__ == "__main__":
    # Note: This requires:
    # 1. AWS credentials configured (aws configure or environment variables)
    # 2. Strands SDK installed (pip install strands-agents)
    # 3. Valid repository URL
    
    print("AutoDeploy Agent System - Strands SDK Example")
    print("=" * 60)
    print("\nPrerequisites:")
    print("1. AWS credentials configured")
    print("2. Strands SDK installed: pip install strands-agents")
    print("3. Valid GitHub repository URL")
    print("\nNote: This is a demonstration. Update repo_url with a real repository.")
    print("=" * 60)
    
    # Uncomment to run:
    # main()
    
    print("\nTo run this example:")
    print("1. Configure AWS credentials: aws configure")
    print("2. Install dependencies: pip install -r requirements.txt")
    print("3. Update repo_url in main() with a real repository")
    print("4. Uncomment main() call above")
    print("5. Run: python example_strands_usage.py")
