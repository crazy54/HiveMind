"""Abe Agent - Deploys and configures applications."""
from typing import Optional
from src.schemas.deployment import BuildArtifact, InfrastructureSpec, DeploymentConfig, TechStack
from src.tools.deployment import (
    ssh_connect,
    install_runtime,
    copy_artifact,
    configure_environment,
    start_service,
    health_check,
    DeploymentToolError,
)


class DeploymentResult:
    """Result of application deployment."""
    
    def __init__(
        self,
        success: bool,
        deployment_config: Optional[DeploymentConfig] = None,
        error_message: Optional[str] = None,
    ):
        self.success = success
        self.deployment_config = deployment_config
        self.error_message = error_message


class AbeAgent:
    """
    Abe Agent deploys and configures applications.
    
    Responsibilities:
    - Connects to provisioned infrastructure
    - Installs runtime dependencies
    - Deploys application artifacts
    - Configures environment variables
    - Starts application services
    - Verifies application health
    """
    
    def __init__(self, ssh_key_path: str = "~/.ssh/id_rsa"):
        """
        Initialize Abe Agent.
        
        Args:
            ssh_key_path: Path to SSH private key
        """
        self.ssh_key_path = ssh_key_path
    
    def deploy_application(
        self,
        build_artifact: BuildArtifact,
        infrastructure: InfrastructureSpec,
        tech_stack: TechStack,
    ) -> DeploymentResult:
        """
        Deploy application to provisioned infrastructure.
        
        Args:
            build_artifact: Built application artifact
            infrastructure: Provisioned AWS resources
            tech_stack: Application technology stack
            
        Returns:
            DeploymentResult with deployment configuration
        """
        try:
            # Connect to instance
            client = ssh_connect(
                host=infrastructure.instance_public_ip,
                username="ec2-user",
                key_file=self.ssh_key_path,
            )
            
            # Install runtime
            install_runtime(
                client,
                tech_stack.language,
                tech_stack.runtime_version,
            )
            
            # Copy artifact
            remote_path = "/home/ec2-user/app"
            copy_artifact(client, build_artifact.artifact_path, remote_path)
            
            # Configure environment
            env_vars = self._build_environment_vars(infrastructure, tech_stack)
            configure_environment(client, env_vars)
            
            # Start service
            start_command = self._build_start_command(tech_stack, remote_path)
            service_name = f"app-{tech_stack.language}"
            
            start_service(
                client,
                service_name=service_name,
                start_command=start_command,
                working_directory=remote_path,
            )
            
            client.close()
            
            # Verify health
            app_port = self._determine_app_port(tech_stack)
            health_check(
                infrastructure.instance_public_ip,
                app_port,
                "/health",
            )
            
            # Create deployment config
            deployment_config = DeploymentConfig(
                app_port=app_port,
                environment_vars=env_vars,
                health_check_path="/health",
                startup_command=start_command,
                working_directory=remote_path,
                service_name=service_name,
                service_status="running",
                log_file=f"/var/log/{service_name}.log",
            )
            
            return DeploymentResult(
                success=True,
                deployment_config=deployment_config,
            )
            
        except DeploymentToolError as e:
            return DeploymentResult(
                success=False,
                error_message=f"Deployment failed: {str(e)}",
            )
        except Exception as e:
            return DeploymentResult(
                success=False,
                error_message=f"Unexpected error: {str(e)}",
            )
    
    def _build_environment_vars(
        self,
        infrastructure: InfrastructureSpec,
        tech_stack: TechStack,
    ) -> dict:
        """Build environment variables for application."""
        env_vars = {}
        
        # Add database connection if available
        if infrastructure.database_endpoint:
            db_url = self._build_database_url(infrastructure, tech_stack)
            env_vars["DATABASE_URL"] = db_url
            env_vars["DB_HOST"] = infrastructure.database_endpoint
            env_vars["DB_PORT"] = str(infrastructure.database_port)
            env_vars["DB_NAME"] = infrastructure.database_name
            env_vars["DB_USER"] = infrastructure.database_username
            env_vars["DB_PASSWORD"] = infrastructure.database_password
        
        # Add application port
        env_vars["PORT"] = str(self._determine_app_port(tech_stack))
        
        # Add Node environment
        env_vars["NODE_ENV"] = "production"
        
        return env_vars
    
    def _build_database_url(
        self,
        infrastructure: InfrastructureSpec,
        tech_stack: TechStack,
    ) -> str:
        """Build database connection URL."""
        db_type = tech_stack.database_type or "postgresql"
        
        if db_type == "postgresql":
            protocol = "postgresql"
        elif db_type == "mysql":
            protocol = "mysql"
        else:
            protocol = db_type
        
        return (
            f"{protocol}://{infrastructure.database_username}:"
            f"{infrastructure.database_password}@"
            f"{infrastructure.database_endpoint}:"
            f"{infrastructure.database_port}/"
            f"{infrastructure.database_name}"
        )
    
    def _build_start_command(self, tech_stack: TechStack, working_dir: str) -> str:
        """Build command to start the application."""
        if tech_stack.language == "nodejs":
            if tech_stack.start_command:
                return f"node {tech_stack.start_command}"
            return "npm start"
        elif tech_stack.language == "python":
            if tech_stack.framework == "fastapi":
                return "uvicorn main:app --host 0.0.0.0 --port 8000"
            elif tech_stack.framework == "flask":
                return "python app.py"
            elif tech_stack.framework == "django":
                return "python manage.py runserver 0.0.0.0:8000"
            return "python main.py"
        elif tech_stack.language == "go":
            return f"{working_dir}/app"
        
        return "npm start"
    
    def _determine_app_port(self, tech_stack: TechStack) -> int:
        """Determine application port."""
        framework_ports = {
            "express": 3000,
            "nextjs": 3000,
            "fastapi": 8000,
            "flask": 5000,
            "django": 8000,
            "gin": 8080,
        }
        
        if tech_stack.framework in framework_ports:
            return framework_ports[tech_stack.framework]
        
        language_ports = {
            "nodejs": 3000,
            "python": 8000,
            "go": 8080,
        }
        
        return language_ports.get(tech_stack.language, 3000)
