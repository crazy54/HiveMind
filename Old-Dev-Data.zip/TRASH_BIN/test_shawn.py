"""Unit tests for Shawn Agent."""
import pytest
from unittest.mock import Mock, patch
from src.agents.shawn import ShawnAgent
from src.schemas.deployment import InfrastructureSpec, DeploymentConfig


@pytest.mark.unit
@patch('src.agents.shawn.review_security_groups')
@patch('src.agents.shawn.ssh_connect')
@patch('src.agents.shawn.harden_os')
@patch('src.agents.shawn.configure_firewall')
@patch('src.agents.shawn.run_vulnerability_scan')
def test_shawn_harden_security_success(
    mock_scan, mock_firewall, mock_harden, mock_connect, mock_review
):
    """Test successful security hardening."""
    mock_review.return_value = {"security_groups": [], "issues": []}
    mock_harden.return_value = {"updates_installed": True, "firewall_enabled": True}
    mock_scan.return_value = {"vulnerabilities_found": 0}
    mock_connect.return_value = Mock()
    
    infrastructure = InfrastructureSpec(
        vpc_id="vpc-123",
        instance_id="i-123",
        instance_public_ip="192.168.1.100",
        security_group_ids=["sg-123"],
    )
    
    deployment_config = DeploymentConfig(app_port=3000)
    
    agent = ShawnAgent()
    result = agent.harden_security(infrastructure, deployment_config)
    
    assert result.success is True
    assert result.security_config is not None
    assert result.security_config.firewall_enabled is True
