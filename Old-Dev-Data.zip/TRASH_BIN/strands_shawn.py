"""Shawn Agent using Strands SDK."""
from strands import Agent
from src.tools.security_tools import (
    review_security_groups,
    harden_operating_system,
    configure_firewall_rules,
    run_security_scan,
)


shawn_agent = Agent(
    name="Shawn",
    system_prompt="""You are Shawn, the Security Agent responsible for hardening infrastructure and application security.

Your responsibilities:
1. Review security group rules for overly permissive access
2. Harden operating system security (updates, firewall, disable unnecessary services)
3. Configure firewall rules to allow only required ports
4. Run vulnerability scans
5. Ensure compliance with security best practices

When given infrastructure and deployment configuration:
1. Use review_security_groups to audit security group rules
2. Use harden_operating_system to update packages, enable firewall, disable unnecessary services
3. Use configure_firewall_rules to allow only required ports (SSH: 22, HTTP: 80, HTTPS: 443, App port)
4. Use run_security_scan to check for vulnerabilities

Security best practices:
- Only allow SSH (22), HTTP (80), HTTPS (443), and application port
- Enable and configure firewall
- Keep system packages updated
- Disable unnecessary services (telnet, rsh, rlogin)
- Run vulnerability scans regularly

Always provide complete security details including:
- Security group analysis
- OS hardening results
- Firewall configuration
- Vulnerability scan results
- Compliance status""",
    tools=[
        review_security_groups,
        harden_operating_system,
        configure_firewall_rules,
        run_security_scan,
    ],
)


def run_shawn_agent(
    infrastructure: dict,
    deployment_config: dict,
    ssh_key_path: str,
) -> dict:
    """Run Shawn agent to harden security."""
    message = f"""Please harden security for the deployed application:

Infrastructure:
- Instance IP: {infrastructure.get('instance_public_ip')}
- Instance ID: {infrastructure.get('instance_id')}
- Security Groups: {infrastructure.get('security_group_ids')}

Deployment:
- Application Port: {deployment_config.get('app_port')}

SSH Key: {ssh_key_path}

Steps to follow:
1. Review security group rules
2. Harden operating system
3. Configure firewall (allow ports: 22, 80, 443, {deployment_config.get('app_port')})
4. Run vulnerability scan

Provide complete security hardening results."""

    result = shawn_agent(message)
    
    return {
        "success": True,
        "response": result.content,
        "tool_calls": [
            {"tool": call.get("name"), "result": call.get("result")}
            for call in result.tool_calls
        ] if hasattr(result, "tool_calls") else []
    }
