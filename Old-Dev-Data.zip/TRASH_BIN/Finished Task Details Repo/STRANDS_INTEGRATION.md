# Strands SDK Integration

## Overview

The AutoDeploy Agent System now integrates with the Strands SDK for AI agent orchestration. This provides:
- Automatic tool selection by LLM
- Built-in agent loop and reasoning
- Traces and metrics for observability
- OpenTelemetry integration

## Architecture

### Dual Implementation

The codebase now has **two implementations**:

1. **Original Implementation** (`src/agents/*.py`)
   - Regular Python classes
   - Direct method calls
   - Fully functional and tested
   - Good for understanding the logic

2. **Strands Implementation** (`src/agents/strands_*.py`)
   - Uses Strands SDK
   - LLM-driven tool selection
   - Agent-based orchestration
   - Production-ready

### File Structure

```
src/
├── agents/
│   ├── conductor.py              # Original Conductor (Python class)
│   ├── compiler.py               # Original Compiler (Python class)
│   ├── server_monkey.py          # Original Server-Monkey (Python class)
│   ├── strands_conductor.py      # Strands Conductor Agent
│   ├── strands_compiler.py       # Strands Compiler Agent
│   └── strands_server_monkey.py  # Strands Server-Monkey Agent
├── tools/
│   ├── repository.py             # Core repository functions
│   ├── build.py                  # Core build functions
│   ├── aws_infrastructure.py     # Core AWS functions
│   ├── deployment.py             # Core deployment functions
│   ├── repository_tools.py       # Strands @tool wrappers
│   ├── build_tools.py            # Strands @tool wrappers
│   ├── infrastructure_tools.py   # Strands @tool wrappers
│   └── deployment_tools.py       # Strands @tool wrappers
```

## How Strands Integration Works

### 1. Tools with @tool Decorator

Tools are Python functions decorated with `@tool`:

```python
from strands import tool

@tool
def analyze_repository(repo_url: str, local_path: str) -> dict:
    """
    Analyze repository and detect complete tech stack.
    
    Args:
        repo_url: Repository URL to analyze
        local_path: Local path for cloning
        
    Returns:
        Dictionary with tech stack information
    """
    # Implementation...
```

### 2. Agents with Instructions

Agents are created with instructions and tools:

```python
from strands import Agent

compiler_agent = Agent(
    name="Compiler",
    instructions="""You are the Compiler Agent responsible for analyzing and building applications.
    
    Your responsibilities:
    1. Clone the repository
    2. Analyze the tech stack
    3. Build the application
    
    When given a repository URL and deployment ID:
    1. Use clone_repository to clone the repo
    2. Use analyze_repository to detect the tech stack
    3. Use build_application to build the application""",
    tools=[clone_repository, analyze_repository, build_application],
)
```

### 3. Agent Execution

Agents are called with natural language messages:

```python
result = compiler_agent(f"""Please analyze and build the application from:
Repository URL: {repo_url}
Deployment ID: {deployment_id}""")
```

The LLM automatically:
- Decides which tools to use
- Calls tools in the right order
- Handles errors and retries
- Returns structured results

### 4. Conductor Orchestration

The Conductor coordinates multiple agents:

```python
# Step 1: Compiler Agent
compiler_result = run_compiler_agent(repo_url, deployment_id)

# Step 2: Server-Monkey Agent
infra_result = run_server_monkey_agent(tech_stack, deployment_id)

# Step 3: Abe Agent (TODO)
# Step 4: Shawn Agent (TODO)
```

## Usage

### Using Strands Agents

```python
from src.agents.strands_conductor import StrandsConductorAgent

# Create conductor
conductor = StrandsConductorAgent(
    state_dir="./deployments",
    region="us-east-1"
)

# Deploy application
result = conductor.deploy(
    repo_url="https://github.com/user/my-app",
    description="Deploy my Node.js application"
)

print(f"Deployment ID: {result.deployment_id}")
print(f"Status: {result.state.status}")
```

### Using Original Implementation

```python
from src.agents.conductor import ConductorAgent

# Create conductor
conductor = ConductorAgent(state_dir="./deployments")

# Deploy application
result = conductor.deploy(
    repo_url="https://github.com/user/my-app",
    description="Deploy my Node.js application"
)
```

## Benefits of Strands Integration

### 1. Intelligent Tool Selection
The LLM automatically decides which tools to use and in what order, adapting to different scenarios.

### 2. Natural Language Interface
Agents can be instructed in plain English, making them easier to configure and extend.

### 3. Built-in Observability
Strands provides traces, metrics, and tool usage statistics out of the box:

```python
result = agent(message)
print(result.metrics.get_summary())
```

### 4. Error Handling
The agent loop automatically handles errors and can retry operations.

### 5. Extensibility
Adding new capabilities is as simple as:
1. Create a new `@tool` function
2. Add it to the agent's tools list
3. Update the agent's instructions

## Configuration

### AWS Credentials

Strands uses Amazon Bedrock by default. Configure AWS credentials:

```bash
export AWS_ACCESS_KEY_ID=your_key
export AWS_SECRET_ACCESS_KEY=your_secret
export AWS_REGION=us-east-1
```

Or use AWS credentials file:
```bash
aws configure
```

### Model Selection

By default, agents use Claude 4 via Amazon Bedrock. You can configure different models in the Agent constructor.

## Testing

### Testing Strands Agents

The existing tests work with both implementations:

```bash
# Run all tests
pytest -v

# Run specific test
pytest tests/test_conductor.py -v
```

### Testing Tools

Tools can be tested independently:

```python
from src.tools.repository_tools import analyze_repository

result = analyze_repository(
    repo_url="https://github.com/user/repo",
    local_path="./test_repo"
)
```

## Migration Path

### Current Status

- ✅ Core tools implemented
- ✅ Strands tool wrappers created
- ✅ Compiler Agent (Strands)
- ✅ Server-Monkey Agent (Strands)
- ✅ Conductor Agent (Strands)
- ⏳ Abe Agent (TODO)
- ⏳ Shawn Agent (TODO)

### Next Steps

1. **Complete Abe Agent**: Create `strands_abe.py` with deployment tools
2. **Complete Shawn Agent**: Create `strands_shawn.py` with security tools
3. **Integration Testing**: Test full workflow with Strands agents
4. **Observability**: Add metrics collection and monitoring
5. **Production Deployment**: Deploy with proper AWS credentials

## Troubleshooting

### Issue: Agent not using tools

**Solution**: Check that:
- Tools are properly decorated with `@tool`
- Tools are included in the agent's `tools` list
- Tool docstrings are clear and descriptive

### Issue: AWS credentials not found

**Solution**: Ensure AWS credentials are configured:
```bash
aws configure
# or
export AWS_ACCESS_KEY_ID=...
export AWS_SECRET_ACCESS_KEY=...
```

### Issue: Import errors

**Solution**: Install Strands SDK:
```bash
pip install strands-agents strands-agents-tools
```

## Best Practices

### 1. Clear Tool Descriptions

Write detailed docstrings for tools - the LLM uses these to decide when to use each tool.

### 2. Structured Returns

Return dictionaries or Pydantic models from tools for easy parsing.

### 3. Error Handling

Raise `ValueError` with clear messages when tools fail - the agent will see these and can adapt.

### 4. Atomic Tools

Keep tools focused on single responsibilities. Better to have many small tools than few large ones.

### 5. Stateless Tools

Tools should be stateless - all context should be passed as parameters.

## Resources

- [Strands Documentation](https://strandsagents.com/latest/documentation/)
- [Strands GitHub](https://github.com/strands-agents)
- [Strands Tools](https://github.com/strands-agents/tools)
- [Strands MCP Server](https://github.com/strands-agents/mcp-server)

## Support

For issues with:
- **Strands SDK**: Check [Strands documentation](https://strandsagents.com)
- **AutoDeploy implementation**: Review this document and code comments
- **AWS integration**: Check AWS credentials and permissions
