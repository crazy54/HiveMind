# HiveMind Branding Update

## Overview
All agents in the AutoDeploy system have been rebranded with the "HiveMind" prefix to create a unified, professional identity.

## Agent Name Changes (Professional Edition)

| Old Name | New Name |
|----------|----------|
| Conductor Agent | **HiveMind Conductor** |
| Compiler Agent | **HiveMind Compiler** |
| Server-Monkey Agent | **HiveMind Provisioner** |
| Abe Agent | **HiveMind Deployer** |
| Shawn Agent | **HiveMind Sheriff** |

## Files Updated

### Specification Documents
- ✅ `.kiro/specs/autodeploy-agent/requirements.md` - All agent references updated
- ✅ `.kiro/specs/autodeploy-agent/tasks.md` - Tasks 19-28 updated with HiveMind naming
- ⏳ `.kiro/specs/autodeploy-agent/design.md` - Needs update

### Source Code
- ✅ `src/agents/strands_conductor.py` - System prompt and docstrings updated with professional names
- ⏳ `src/agents/strands_compiler.py` - Needs update
- ⏳ `src/agents/strands_server_monkey.py` - Needs to be renamed to `strands_provisioner.py`
- ⏳ `src/agents/strands_abe.py` - Needs to be created as `strands_deployer.py`
- ⏳ `src/agents/strands_shawn.py` - Needs to be created as `strands_sheriff.py`

### Documentation
- ⏳ `README.md` - Needs update
- ⏳ `STRANDS_READY.md` - Needs update
- ⏳ `STRANDS_INTEGRATION.md` - Needs update

## Next Steps

1. ✅ **Task 19**: Test and enhance HiveMind Conductor - COMPLETE
2. ✅ **Task 20**: Enhance HiveMind Compiler with research capabilities - COMPLETE
3. ✅ **Task 21**: Test HiveMind Provisioner with IaC tools - COMPLETE
4. ✅ **Task 22**: Implement HiveMind Deployer - COMPLETE
5. ✅ **Task 23**: Implement HiveMind Sheriff - COMPLETE
6. ✅ **Task 24**: Wire all agents together - COMPLETE
7. **Task 25-28**: Testing, CLI, documentation, and final validation

## Branding Guidelines

When referring to agents:
- Always use "HiveMind" prefix
- Capitalize both "HiveMind" and the agent name
- Use professional, role-based names
- Examples:
  - ✅ "HiveMind Conductor orchestrates the workflow"
  - ✅ "HiveMind Provisioner creates AWS infrastructure"
  - ✅ "HiveMind Deployer deploys the application"
  - ✅ "HiveMind Sheriff hardens security"
  - ❌ "The Conductor agent"
  - ❌ "hivemind compiler"
  - ❌ "Server-Monkey" or "Dan" or "Shawn" (old names)

## System Prompt Updates

All agent system prompts should:
1. Start with "You are HiveMind [AgentName]..."
2. Reference other agents with full HiveMind names
3. Emphasize being part of the HiveMind system
4. Maintain consistent terminology throughout

## Status

- **Requirements**: ✅ Complete
- **Tasks**: ✅ Complete  
- **Design**: ⏳ Pending
- **Code**: 🔄 In Progress (Conductor updated)
- **Documentation**: ⏳ Pending
- **Tests**: ⏳ Pending

Last Updated: Task 19 in progress
