# Testing HiveMind System

## Quick Start

### 1. Validate System Setup
```bash
python validate_system.py
```
This checks that all agents are properly installed and configured.

### 2. Run Test Suite
```bash
# Run all tests
pytest -v

# Run with coverage
pytest --cov=src tests/

# Run quietly (faster)
pytest -q
```

## Test Categories

### Unit Tests (Fast)
Test individual agent functions in isolation:

```bash
# Test HiveMind Compiler
pytest tests/test_compiler_enhanced.py -v

# Test HiveMind Provisioner
pytest tests/test_provisioner_enhanced.py -v

# Test HiveMind Deployer
pytest tests/test_deployer.py -v

# Test HiveMind Sheriff
pytest tests/test_sheriff.py -v
```

### Integration Tests (Slower)
Test complete workflows:

```bash
# Test complete deployment workflow
pytest tests/test_complete_workflow.py -v

# Run only integration tests
pytest -v -m integration
```

## Manual Testing

### Test Individual Agents

```bash
python test_agents_manual.py
```

Edit the file to uncomment specific agent tests:
- `test_compiler()` - Test build and analysis
- `test_provisioner()` - Test infrastructure provisioning
- `test_deployer()` - Test application deployment
- `test_sheriff()` - Test security hardening
- `test_complete_workflow()` - Test all agents together

### Test with Python REPL

```python
# Start Python
python

# Test Conductor
from src.agents.strands_conductor import StrandsConductorAgent
conductor = StrandsConductorAgent()
result = conductor.deploy(
    repo_url="https://github.com/test/app",
    description="Test deployment"
)
print(result.success)
print(result.message)

# Check deployment status
state = conductor.get_status(result.deployment_id)
print(state.status)
for log in state.logs:
    print(log)
```

## Test Scenarios

### Scenario 1: Node.js Application
```python
from src.agents.strands_conductor import StrandsConductorAgent

conductor = StrandsConductorAgent()
result = conductor.deploy(
    repo_url="https://github.com/user/nodejs-app",
    description="Deploy Node.js Express application"
)
```

### Scenario 2: Python with Database
```python
conductor = StrandsConductorAgent()
result = conductor.deploy(
    repo_url="https://github.com/user/django-app",
    description="Deploy Django app with PostgreSQL database"
)
```

### Scenario 3: Go Microservice
```python
conductor = StrandsConductorAgent()
result = conductor.deploy(
    repo_url="https://github.com/user/go-api",
    description="Deploy Go microservice"
)
```

## Debugging Tests

### Run Specific Test
```bash
pytest tests/test_complete_workflow.py::test_complete_deployment_workflow -v
```

### Run with Debug Output
```bash
pytest tests/test_deployer.py -v -s
```

### Run Failed Tests Only
```bash
pytest --lf  # Last failed
pytest --ff  # Failed first
```

## Test Coverage

### Generate Coverage Report
```bash
# Run tests with coverage
pytest --cov=src --cov-report=html tests/

# Open coverage report
open htmlcov/index.html  # macOS
xdg-open htmlcov/index.html  # Linux
```

### Coverage by Agent
```bash
# Compiler coverage
pytest --cov=src.agents.strands_compiler tests/test_compiler_enhanced.py

# Provisioner coverage
pytest --cov=src.agents.strands_server_monkey tests/test_provisioner_enhanced.py

# Deployer coverage
pytest --cov=src.agents.strands_deployer tests/test_deployer.py

# Sheriff coverage
pytest --cov=src.agents.strands_sheriff tests/test_sheriff.py
```

## Performance Testing

### Measure Test Duration
```bash
pytest --durations=10  # Show 10 slowest tests
```

### Profile Tests
```bash
pytest --profile
```

## Continuous Testing

### Watch Mode (requires pytest-watch)
```bash
pip install pytest-watch
ptw  # Runs tests on file changes
```

### Pre-commit Testing
```bash
# Add to .git/hooks/pre-commit
#!/bin/bash
pytest -q
if [ $? -ne 0 ]; then
    echo "Tests failed. Commit aborted."
    exit 1
fi
```

## Test Data

### Mock Data Locations
- `tests/fixtures/` - Test fixtures (if needed)
- `tests/mocks/` - Mock objects (if needed)
- `./test_deployments/` - Test deployment states

### Clean Test Data
```bash
rm -rf ./test_deployments/
rm -rf ./repos/test-*
```

## Common Issues

### Issue: Import Errors
**Solution:**
```bash
# Ensure you're in the project root
export PYTHONPATH="${PYTHONPATH}:$(pwd)"

# Or install in development mode
pip install -e .
```

### Issue: Strands SDK Not Found
**Solution:**
```bash
pip install strands-agents
```

### Issue: Tests Timeout
**Solution:**
```bash
# Run with increased timeout
pytest --timeout=300
```

### Issue: AWS Credentials
**Solution:**
```bash
# Set up AWS credentials
aws configure

# Or use environment variables
export AWS_ACCESS_KEY_ID=your_key
export AWS_SECRET_ACCESS_KEY=your_secret
export AWS_REGION=us-east-1
```

## Test Checklist

Before considering the system ready:

- [ ] All unit tests pass
- [ ] All integration tests pass
- [ ] System validation passes
- [ ] Manual test of complete workflow succeeds
- [ ] Test coverage > 80%
- [ ] No critical diagnostics errors
- [ ] All 5 agents can be imported
- [ ] Conductor can orchestrate all agents

## Next Steps

After testing:

1. **If tests pass**: System is ready for use!
2. **If tests fail**: Check error messages and fix issues
3. **For production**: Add more integration tests with real AWS resources
4. **For CI/CD**: Set up automated testing pipeline

## Quick Commands Reference

```bash
# Validate system
python validate_system.py

# Run all tests
pytest -v

# Run specific agent tests
pytest tests/test_compiler_enhanced.py -v
pytest tests/test_provisioner_enhanced.py -v
pytest tests/test_deployer.py -v
pytest tests/test_sheriff.py -v

# Run integration tests
pytest tests/test_complete_workflow.py -v

# Manual testing
python test_agents_manual.py

# Coverage report
pytest --cov=src --cov-report=html tests/
```

---

**Happy Testing! 🧪**
