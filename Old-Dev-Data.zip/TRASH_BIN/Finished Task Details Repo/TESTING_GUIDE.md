# Testing Guide for AutoDeploy Agent System

## Quick Start

### 1. Install Dependencies

```bash
# Activate virtual environment
source .venv/bin/activate  # macOS/Linux
# or
.venv\Scripts\activate  # Windows

# Install all dependencies
pip install -r requirements.txt
```

### 2. Run All Tests

```bash
# Run all tests with verbose output
pytest -v

# Run with coverage report
pytest --cov=src --cov-report=html tests/

# Run with minimal output (faster)
pytest -q
```

## Running Specific Test Types

### Property-Based Tests

```bash
# Run only property tests
pytest -m property -v

# Run property tests with more examples
pytest -m property --hypothesis-show-statistics
```

### Unit Tests

```bash
# Run only unit tests
pytest -m unit -v

# Run unit tests quietly
pytest -m unit -q
```

### Integration Tests

```bash
# Run integration tests
pytest -m integration -v
```

## Running Specific Test Files

```bash
# Test Conductor Agent
pytest tests/test_conductor.py -v

# Test Compiler Agent
pytest tests/test_build_processes.py -v

# Test AWS Infrastructure
pytest tests/test_aws_resources.py -v

# Test Repository Analysis
pytest tests/test_tech_stack_detection.py -v

# Test Deployment Tools
pytest tests/test_deployment_tools.py -v

# Test Security
pytest tests/test_security.py -v

# Test Error Handling
pytest tests/test_error_handling.py -v

# Test CLI
pytest tests/test_cli.py -v
```

## Running Specific Tests

```bash
# Run a specific test function
pytest tests/test_conductor.py::test_conductor_creates_deployment_state -v

# Run tests matching a pattern
pytest -k "test_conductor" -v

# Run tests matching multiple patterns
pytest -k "test_conductor or test_compiler" -v
```

## Test Output Options

```bash
# Verbose output with test names
pytest -v

# Quiet output (just dots)
pytest -q

# Show print statements
pytest -s

# Stop on first failure
pytest -x

# Show local variables on failure
pytest -l

# Show slowest tests
pytest --durations=10
```

## Coverage Reports

```bash
# Generate HTML coverage report
pytest --cov=src --cov-report=html tests/
# Open htmlcov/index.html in browser

# Terminal coverage report
pytest --cov=src --cov-report=term tests/

# Coverage for specific module
pytest --cov=src.agents --cov-report=term tests/
```

## Testing Individual Components

### Test Repository Analysis

```bash
# Test repository cloning and analysis
pytest tests/test_repository_clone.py -v
pytest tests/test_tech_stack_detection.py -v
```

### Test Build Process

```bash
# Test build tools
pytest tests/test_build_processes.py -v
pytest tests/test_build_artifact_integrity.py -v
```

### Test AWS Infrastructure

```bash
# Test AWS resource creation (uses moto for mocking)
pytest tests/test_aws_resources.py -v
pytest tests/test_infrastructure_idempotency.py -v
```

### Test Agents

```bash
# Test all agents
pytest tests/test_conductor.py -v
pytest tests/test_server_monkey.py -v
pytest tests/test_abe.py -v
pytest tests/test_shawn.py -v
```

## Manual Testing with Python

### Test Repository Analysis

```python
from src.tools.repository import analyze_repository

# Analyze a real repository
tech_stack = analyze_repository(
    "https://github.com/octocat/Hello-World",
    "./test_repo"
)

print(f"Language: {tech_stack.language}")
print(f"Framework: {tech_stack.framework}")
print(f"Dependencies: {tech_stack.dependencies}")
```

### Test Strands Agents

```python
from src.agents.strands_compiler import run_compiler_agent

# Test compiler agent
result = run_compiler_agent(
    repo_url="https://github.com/user/my-app",
    deployment_id="test-123"
)

print(f"Success: {result['success']}")
print(f"Response: {result['response']}")
```

### Test Conductor

```python
from src.agents.strands_conductor import StrandsConductorAgent

# Create conductor
conductor = StrandsConductorAgent(
    state_dir="./test_deployments"
)

# Test deployment (will fail without AWS credentials)
result = conductor.deploy(
    repo_url="https://github.com/user/my-app",
    description="Test deployment"
)

print(f"Deployment ID: {result.deployment_id}")
print(f"Success: {result.success}")
```

## Testing with CLI

### Test CLI Commands

```bash
# Test deploy command (dry run - will fail without AWS)
python -m src.cli deploy https://github.com/user/app "Test deployment"

# Test status command
python -m src.cli status <deployment-id>

# Test retry command
python -m src.cli retry <deployment-id>
```

## Testing with Mock Data

### Create Test Fixtures

```python
# tests/conftest.py
import pytest
from src.schemas.deployment import TechStack, BuildArtifact, InfrastructureSpec

@pytest.fixture
def sample_tech_stack():
    return TechStack(
        language="nodejs",
        framework="express",
        runtime_version="18.x",
        package_manager="npm",
    )

@pytest.fixture
def sample_build_artifact():
    return BuildArtifact(
        artifact_path="/tmp/build",
        artifact_type="nodejs_package",
        size_bytes=1024000,
        checksum="abc123",
    )

# Use in tests
def test_something(sample_tech_stack):
    assert sample_tech_stack.language == "nodejs"
```

## Debugging Tests

### Run with Python Debugger

```bash
# Run with pdb on failure
pytest --pdb

# Run with pdb on first failure
pytest -x --pdb
```

### Add Breakpoints in Tests

```python
def test_something():
    result = some_function()
    
    # Add breakpoint
    import pdb; pdb.set_trace()
    
    assert result == expected
```

### Verbose Logging

```python
import logging
logging.basicConfig(level=logging.DEBUG)

# Your test code here
```

## Common Issues and Solutions

### Issue: Import Errors

```bash
# Solution: Install in development mode
pip install -e .

# Or add src to PYTHONPATH
export PYTHONPATH="${PYTHONPATH}:$(pwd)/src"
```

### Issue: AWS Tests Failing

```bash
# Solution: Tests use moto for mocking, ensure it's installed
pip install moto[all]

# Or skip AWS tests
pytest -v -k "not aws"
```

### Issue: Hypothesis Tests Slow

```bash
# Solution: Reduce number of examples
pytest -v --hypothesis-profile=dev

# Or in test file:
@given(...)
@settings(max_examples=10)
def test_something(...):
    pass
```

### Issue: Tests Timing Out

```bash
# Solution: Increase timeout
pytest --timeout=300

# Or skip slow tests
pytest -v -m "not slow"
```

## Continuous Integration

### GitHub Actions Example

```yaml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.10'
    
    - name: Install dependencies
      run: |
        pip install -r requirements.txt
    
    - name: Run tests
      run: |
        pytest --cov=src --cov-report=xml
    
    - name: Upload coverage
      uses: codecov/codecov-action@v2
```

## Test Organization

```
tests/
├── conftest.py                      # Shared fixtures
├── test_conductor.py                # Conductor tests
├── test_compiler.py                 # Compiler tests
├── test_server_monkey.py            # Infrastructure tests
├── test_abe.py                      # Deployment tests
├── test_shawn.py                    # Security tests
├── test_repository_clone.py         # Property tests
├── test_tech_stack_detection.py     # Unit tests
├── test_build_processes.py          # Build tests
├── test_build_artifact_integrity.py # Property tests
├── test_aws_resources.py            # AWS tests (moto)
├── test_infrastructure_idempotency.py # Property tests
├── test_deployment_tools.py         # Deployment tests
├── test_deployment_health.py        # Property tests
├── test_security.py                 # Security tests
├── test_error_handling.py           # Error tests
├── test_state_transitions.py        # Property tests
├── test_agent_handoff.py            # Property tests
└── test_cli.py                      # CLI tests
```

## Best Practices

1. **Run tests before committing**
   ```bash
   pytest -v
   ```

2. **Check coverage regularly**
   ```bash
   pytest --cov=src --cov-report=term-missing
   ```

3. **Use markers for test organization**
   ```python
   @pytest.mark.unit
   @pytest.mark.slow
   @pytest.mark.integration
   ```

4. **Keep tests fast**
   - Use mocks for external services
   - Use fixtures for common setup
   - Run slow tests separately

5. **Write descriptive test names**
   ```python
   def test_conductor_creates_deployment_state_with_unique_id():
       # Clear what's being tested
   ```

## Quick Test Commands Reference

```bash
# Most common commands
pytest -v                              # All tests, verbose
pytest -q                              # All tests, quiet
pytest -x                              # Stop on first failure
pytest -k "conductor"                  # Tests matching pattern
pytest tests/test_conductor.py         # Specific file
pytest --cov=src                       # With coverage
pytest -m unit                         # Only unit tests
pytest -m property                     # Only property tests
pytest --lf                            # Run last failed
pytest --ff                            # Run failed first
```

## Next Steps

1. **Run all tests**: `pytest -v`
2. **Check coverage**: `pytest --cov=src --cov-report=html`
3. **Fix any failures**: Review error messages
4. **Add new tests**: As you add features

## Getting Help

- **pytest documentation**: https://docs.pytest.org/
- **hypothesis documentation**: https://hypothesis.readthedocs.io/
- **moto documentation**: https://docs.getmoto.org/

---

**Ready to test!** Run `pytest -v` to get started. 🧪
