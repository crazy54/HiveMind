"""Manual testing script for HiveMind agents."""

# Test HiveMind Compiler
def test_compiler():
    from src.agents.strands_compiler import run_compiler_agent
    
    result = run_compiler_agent(
        repo_url="https://github.com/test/sample-app",
        deployment_id="test-123"
    )
    
    print("Compiler Result:")
    print(f"Success: {result['success']}")
    print(f"Response: {result['response']}")
    print(f"Tool Calls: {len(result.get('tool_calls', []))}")
    return result


# Test HiveMind Provisioner
def test_provisioner():
    from src.agents.strands_server_monkey import run_provisioner_agent
    
    tech_stack = {
        "language": "nodejs",
        "framework": "express",
        "requires_database": False
    }
    
    result = run_provisioner_agent(
        tech_stack=tech_stack,
        deployment_id="test-456",
        region="us-east-1"
    )
    
    print("\nProvisioner Result:")
    print(f"Success: {result['success']}")
    print(f"Response: {result['response']}")
    return result


# Test HiveMind Deployer
def test_deployer():
    from src.agents.strands_deployer import run_deployer_agent
    
    build_artifact = {
        "artifact_path": "/build/app.js",
        "artifact_type": "javascript"
    }
    
    infrastructure = {
        "instance_public_ip": "1.2.3.4",
        "instance_id": "i-test123"
    }
    
    tech_stack = {
        "language": "nodejs",
        "framework": "express"
    }
    
    result = run_deployer_agent(
        build_artifact=build_artifact,
        infrastructure=infrastructure,
        tech_stack=tech_stack
    )
    
    print("\nDeployer Result:")
    print(f"Success: {result['success']}")
    print(f"Response: {result['response']}")
    return result


# Test HiveMind Sheriff
def test_sheriff():
    from src.agents.strands_sheriff import run_sheriff_agent
    
    infrastructure = {
        "instance_public_ip": "1.2.3.4",
        "security_group_ids": ["sg-123"]
    }
    
    deployment_config = {
        "app_port": 3000,
        "service_name": "myapp"
    }
    
    result = run_sheriff_agent(
        infrastructure=infrastructure,
        deployment_config=deployment_config
    )
    
    print("\nSheriff Result:")
    print(f"Success: {result['success']}")
    print(f"Response: {result['response']}")
    return result


# Test Complete Workflow
def test_complete_workflow():
    from src.agents.strands_conductor import StrandsConductorAgent
    
    conductor = StrandsConductorAgent(state_dir="./test_deployments")
    
    result = conductor.deploy(
        repo_url="https://github.com/test/sample-app",
        description="Test deployment of sample application"
    )
    
    print("\n" + "="*60)
    print("COMPLETE WORKFLOW TEST")
    print("="*60)
    print(f"Success: {result.success}")
    print(f"Deployment ID: {result.deployment_id}")
    print(f"Message: {result.message}")
    
    if result.state:
        print(f"\nStatus: {result.state.status}")
        print(f"\nLogs:")
        for log in result.state.logs:
            print(f"  {log}")
    
    return result


if __name__ == "__main__":
    print("HiveMind Agent Testing")
    print("="*60)
    
    # Uncomment the tests you want to run:
    
    # test_compiler()
    # test_provisioner()
    # test_deployer()
    # test_sheriff()
    test_complete_workflow()
