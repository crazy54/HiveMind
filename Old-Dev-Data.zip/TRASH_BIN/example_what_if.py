"""Example of using HiveMind AutoDeploy in What-If mode.

This demonstrates the --what-if (dry-run) mode that simulates deployment
without making any actual changes to AWS or your infrastructure.
"""
from src.agents.strands_conductor import StrandsConductorAgent


def example_what_if_deployment():
    """Example: Simulate deployment without making changes."""
    print("=" * 70)
    print("HiveMind AutoDeploy - What-If Mode Example")
    print("=" * 70)
    print()
    
    # Create conductor
    conductor = StrandsConductorAgent(
        state_dir="./deployments",
        region="us-east-1"
    )
    
    # Example 1: Simple Node.js app
    print("📋 Example 1: Node.js Application")
    print("-" * 70)
    
    result = conductor.deploy(
        repo_url="https://github.com/vercel/next.js",
        description="Deploy Next.js application with PostgreSQL",
        dry_run=True  # What-if mode!
    )
    
    if result.success:
        print(f"✅ What-if analysis completed!")
        print(f"Deployment ID: {result.deployment_id}")
        
        if result.state.predicted_costs:
            costs = result.state.predicted_costs
            print(f"\n💰 Estimated Monthly Cost: ${costs['total_monthly']:.2f}")
        
        if result.state.predicted_resources:
            resources = result.state.predicted_resources
            print(f"\n🏗️  Resources to Create:")
            print(f"   - EC2 Instances: {resources['ec2_instances']}")
            print(f"   - RDS Instances: {resources['rds_instances']}")
        
        if result.state.predicted_timeline:
            timeline = result.state.predicted_timeline
            print(f"\n⏱️  Estimated Time: {timeline['total']}")
        
        print(f"\n📝 Analysis Logs:")
        for log in result.state.logs[-5:]:
            print(f"   {log}")
    
    print()
    print("=" * 70)
    print("✅ No actual resources were created!")
    print("=" * 70)


def compare_what_if_vs_real():
    """Compare what-if mode vs real deployment."""
    print("\n" + "=" * 70)
    print("Comparing What-If vs Real Deployment")
    print("=" * 70)
    
    conductor = StrandsConductorAgent()
    
    # What-if mode
    print("\n🔮 WHAT-IF MODE:")
    print("-" * 70)
    what_if_result = conductor.deploy(
        repo_url="https://github.com/example/app",
        description="Test deployment",
        dry_run=True
    )
    
    if what_if_result.success:
        print("✅ Analysis complete - no changes made")
        if what_if_result.state.predicted_costs:
            print(f"💰 Would cost: ${what_if_result.state.predicted_costs['total_monthly']:.2f}/month")
    
    # Real deployment (commented out for safety)
    print("\n🚀 REAL DEPLOYMENT:")
    print("-" * 70)
    print("⚠️  Commented out for safety - would create actual AWS resources")
    print("⚠️  Uncomment below to run real deployment:")
    print()
    print("# real_result = conductor.deploy(")
    print("#     repo_url='https://github.com/example/app',")
    print("#     description='Test deployment',")
    print("#     dry_run=False  # Real deployment!")
    print("# )")


def cli_examples():
    """Show CLI usage examples."""
    print("\n" + "=" * 70)
    print("CLI Usage Examples")
    print("=" * 70)
    
    print("\n1. What-If Mode (Simulate):")
    print("   python -m src.cli deploy https://github.com/user/app 'Deploy my app' --what-if")
    
    print("\n2. Real Deployment:")
    print("   python -m src.cli deploy https://github.com/user/app 'Deploy my app'")
    
    print("\n3. Check Status:")
    print("   python -m src.cli status <deployment-id>")
    
    print("\n4. Retry Failed Deployment:")
    print("   python -m src.cli retry <deployment-id>")
    
    print("\n" + "=" * 70)
    print("💡 Tip: Always use --what-if first to see what would happen!")
    print("=" * 70)


if __name__ == "__main__":
    # Run examples
    example_what_if_deployment()
    compare_what_if_vs_real()
    cli_examples()
    
    print("\n✅ Examples complete!")
    print("📚 See NEXT_STEPS.md for more information")
